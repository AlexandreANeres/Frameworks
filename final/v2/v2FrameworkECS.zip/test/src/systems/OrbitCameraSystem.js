import { System } from "../ecs/System.js";
import { CameraRig } from "../components/CameraRig.js";
import { CameraFollow } from "../components/CameraFollow.js";
import { Transform } from "../components/Transform.js";

export class OrbitCameraSystem extends System {
    constructor(threeCamera) {
        super();
        this.camera = threeCamera;
        this.activeEntity = undefined;
    }

    update(world, dt) {
        if (this.activeEntity === undefined) return;
        const rig = world.getComponent(this.activeEntity, CameraRig);
        const follow = world.getComponent(this.activeEntity, CameraFollow);
        if (!rig || !follow) return;

        const targetTransform = world.getComponent(rig.target, Transform);
        if(!targetTransform) return;

        if (follow.mode === "firstPerson") {
            this.camera.position.set(
                targetTransform.x + follow.offsetX,
                targetTransform.y + follow.offsetY,
                targetTransform.z + follow.offsetZ
            );
            const horizontalScale = Math.cos(rig.pitch);
            this.camera.lookAt(
                this.camera.position.x - Math.sin(rig.yaw) * horizontalScale,
                this.camera.position.y + Math.sin(rig.pitch),
                this.camera.position.z - Math.cos(rig.yaw) * horizontalScale
            );
            return;
        }

        const targetX = targetTransform.x;
        const targetY = targetTransform.y + follow.lookAtHeight;
        const targetZ = targetTransform.z;

        const cosPitch = Math.cos(rig.pitch);
        const sinPitch = Math.sin(rig.pitch);
        const cosYaw = Math.cos(rig.yaw);
        const sinYaw = Math.sin(rig.yaw);

        const distance = rig.distance;

        const desiredX = targetX + sinYaw * cosPitch * distance;
        const desiredY = targetY + sinPitch * distance;
        const desiredZ = targetZ + cosYaw * cosPitch * distance;

        // Smooth follow
        const lerp = 1 - Math.exp(-follow.smoothness * dt);

        this.camera.position.x += (desiredX - this.camera.position.x) * lerp;
        this.camera.position.y += (desiredY - this.camera.position.y) * lerp;
        this.camera.position.z += (desiredZ - this.camera.position.z) * lerp;

        this.camera.lookAt(targetX, targetY, targetZ);
    }
}