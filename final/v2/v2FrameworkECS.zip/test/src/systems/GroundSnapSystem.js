import { System } from "../ecs/System.js";
import { Query } from "../ecs/Query.js";
import { Transform } from "../components/Transform.js";
import { Velocity } from "../components/Velocity.js";
import { Grounded } from "../components/Grounded.js";
import { ControllerSettings } from "../components/ControllerSetting.js";
import { CapsuleCollider } from "../components/CapsuleCollider.js";
import { ColliderAABB } from "../components/ColliderAABB.js";
import { StaticBody } from "../components/StaticBody.js";

export class GroundSnapSystem extends System {
    update(world, dt) {
        const ents = Query.entitiesWith(world, Transform, Velocity, Grounded, ControllerSettings, CapsuleCollider);
        const statics = Query.entitiesWith(world, Transform, ColliderAABB, StaticBody);

        for (const e of ents) {
            const t = world.getComponent(e, Transform);
            const v = world.getComponent(e, Velocity);
            const g = world.getComponent(e, Grounded);
            const s = world.getComponent(e, ControllerSettings);
            const capsule = world.getComponent(e, CapsuleCollider);

            // Only snap when faling slowly / almost grounded
            if (v.y > 0) continue; //moving upward

            if(!g.isWalkable) continue;

            // If we are very close to the ground, snap down a tiny amount
            // We can approximate by checking if we are within snap distance of y=0 plane
            const footY = t.y - capsule.halfHeight - capsule.radius;

            for (const ground of statics) {
                const groundTransform = world.getComponent(ground, Transform);
                const groundCollider = world.getComponent(ground, ColliderAABB);
                const overlapsX = t.x + capsule.radius >= groundTransform.x - groundCollider.halfX
                    && t.x - capsule.radius <= groundTransform.x + groundCollider.halfX;
                const overlapsZ = t.z + capsule.radius >= groundTransform.z - groundCollider.halfZ
                    && t.z - capsule.radius <= groundTransform.z + groundCollider.halfZ;
                const groundY = groundTransform.y + groundCollider.halfY;
                const distanceToGround = footY - groundY;

                if (!overlapsX || !overlapsZ || distanceToGround < 0 || distanceToGround > s.groundSnapDist) {
                    continue;
                }

                t.y = groundY + capsule.halfHeight + capsule.radius;
                v.y = 0;
                g.isGrounded = true;
                g.normalX = 0;
                g.normalY = 1;
                g.normalZ = 0;
                g.slopeAngleDeg = 0;
                g.isWalkable = true;
                break;
            }
        }
    }
}