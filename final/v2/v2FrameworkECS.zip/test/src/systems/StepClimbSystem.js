import { System } from "../ecs/System.js";
import { Query } from "../ecs/Query.js";
import { Transform } from "../components/Transform.js";
import { Velocity } from "../components/Velocity.js";
import { Grounded } from "../components/Grounded.js";
import { ControllerSettings } from "../components/ControllerSetting.js";

export class StepClimbSystem extends System {
    update(world, dt) {
        const ents = Query.entitiesWith(world, Transform, Velocity, Grounded, ControllerSettings);

        for (const e of ents) {
            const t = world.getComponent(e, Transform);
            const v = world.getComponent(e, Velocity);
            const g = world.getComponent(e, Grounded);
            const s = world.getComponent(e, ControllerSettings);

            // Only step when ground & walkable
            if(!g.isGrounded || !g.isWalkable) continue;

            // Only step when trying to move
            const speedXZ = Math.hypot(v.x, v.z);
            if (speedXZ < 0.05) continue;

            // Simple step: If we are close to the ground plane, allow a small upward nudge
            if(t.y < s.stepHeight) {
                // Nudge up a tiny amount per frame while moving
                t.y = Math.min(s.stepHeight, t.y + 0.02);
            }
        }
    }
}