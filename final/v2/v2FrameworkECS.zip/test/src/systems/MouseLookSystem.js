import * as THREE from "three";
import { System } from "../ecs/System.js";
import { CameraRig } from "../components/CameraRig.js";
import { CameraFollow } from "../components/CameraFollow.js";

export class MouseLookSystem extends System {
    constructor(domElement) {
        super();
        this.domElement = domElement;
        this.dx = 0;
        this.dy = 0;
        this.wheel = 0;

        this.isRotating = false;
        this.activeEntity = undefined;
        this.editorCamera = undefined;
        this.inputSystem = undefined;
        this.mode = "editor-free";

        // Prevent right-click menu
        domElement.addEventListener("contextmenu", (e) => e.preventDefault());

        // RMB down = start rotating
        domElement.addEventListener("mousedown", (e) => {
            if (e.button === 2 && this.mode !== "preview") {
                // Right mouse button
                this.isRotating = true;
                domElement.requestPointerLock();
            }
        });

        // Release right mouse button to stop rotating
        window.addEventListener("mouseup", (e) => {
            if (e.button === 2) {
                this.isRotating = false;
                if (document.pointerLockElement === domElement) {
                    document.exitPointerLock();
                }
            }
        })

        // Mouse move
        domElement.addEventListener("mousemove", e => {
            if (document.pointerLockElement === domElement) {
                this.dx += e.movementX;
                this.dy += e.movementY;
            }
        })

        // Zoom
        domElement.addEventListener("wheel", e => {
            e.preventDefault(); // Stop the page from scrolling
            this.wheel += e.deltaY * 0.01;
        }, { passive: false} // allows preventDefault
        );
    }

    setEditorCamera(camera, inputSystem) {
        this.editorCamera = camera;
        this.inputSystem = inputSystem;
    }

    setMode(mode) {
        this.mode = mode;
    }

    update(world, dt) {
        if (this.mode === "editor-free" && this.editorCamera) {
            this.editorCamera.rotation.order = "YXZ";
            this.editorCamera.rotation.y -= this.dx * 0.002;
            this.editorCamera.rotation.x = Math.max(
                -Math.PI / 2,
                Math.min(Math.PI / 2, this.editorCamera.rotation.x - this.dy * 0.002)
            );

            const keys = this.inputSystem?.keys ?? {};
            const forward = this.editorCamera.getWorldDirection(new THREE.Vector3());
            forward.y = 0;
            forward.normalize();
            const right = new THREE.Vector3().crossVectors(
                forward,
                new THREE.Vector3(0, 1, 0)
            ).normalize();
            const movement = new THREE.Vector3();
            movement.addScaledVector(
                forward,
                Number(Boolean(keys.KeyW)) - Number(Boolean(keys.KeyS))
            );
            movement.addScaledVector(
                right,
                Number(Boolean(keys.KeyD)) - Number(Boolean(keys.KeyA))
            );
            movement.y += Number(Boolean(keys.Space)) - Number(Boolean(keys.ShiftLeft));
            if (movement.lengthSq() > 0) {
                this.editorCamera.position.addScaledVector(movement.normalize(), 8 * dt);
            }
        } else if (this.mode === "play" && this.activeEntity !== undefined
            && world.getComponent(this.activeEntity, CameraFollow)) {
            const rig = world.getComponent(this.activeEntity, CameraRig);
            if (rig) {
                rig.yaw -= this.dx * 0.002;
                rig.pitch -= this.dy * 0.002;
                rig.pitch = Math.max(rig.minPitch, Math.min(rig.maxPitch, rig.pitch));

                if (this.wheel) {
                    rig.distance += this.wheel;
                    rig.distance = Math.max(
                        rig.minDistance,
                        Math.min(rig.maxDistance, rig.distance)
                    );
                }
            }
        }

        this.dx = 0;
        this.dy = 0;
        this.wheel = 0;
    }
}