import { System } from "../ecs/System.js";
import { Query } from "../ecs/Query.js";
import { Transform } from "../components/Transform.js";
import { Mesh } from "../components/Mesh.js";
import { CapsuleDebugMesh } from "../components/CapsuleDebugMesh.js";

export class RenderSystem extends System {
    constructor(renderer, scene, camera) {
        super();
        this.renderer = renderer;
        this.scene = scene;
        this.camera = camera;
    }

    update(world, deltaTime) {
        const entities = Query.entitiesWith(world, Transform, Mesh);

        for (const entity of entities) {
            const transform = world.getComponent(entity, Transform);
            const meshComponent = world.getComponent(entity, Mesh);

            meshComponent.mesh.rotation.set(
                transform.rotX,
                transform.rotY,
                transform.rotZ
            );

            meshComponent.mesh.position.set(
                transform.x,
                transform.y,
                transform.z
            );
            meshComponent.mesh.scale.set(
                transform.scaleX,
                transform.scaleY,
                transform.scaleZ
            );
        }

        const debugCaps = Query.entitiesWith(world, Transform, CapsuleDebugMesh);

        for (const e of debugCaps) {
            const t = world.getComponent(e, Transform);
            const debug = world.getComponent(e, CapsuleDebugMesh);
            debug.mesh.position.set(t.x, t.y, t.z);
            debug.mesh.rotation.set(t.rotX, t.rotY, t.rotZ);
            debug.mesh.scale.set(t.scaleX, t.scaleY, t.scaleZ);
        }
        this.renderer.render(this.scene, this.camera);
    }
}