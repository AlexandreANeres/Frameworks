function requireName(name) {
    if (typeof name !== "string" || !name.trim()) {
        throw new Error("Informe um nome para o objeto.");
    }
    return name.trim();
}

function requirePosition(...coordinates) {
    if (!coordinates.every(Number.isFinite)) {
        throw new Error("As posições X, Y e Z precisam ser números válidos.");
    }
}

export function createBeginnerTools(initializer) {
    return {
        StartPlayer() {
            const existing = initializer.objects.find((object) => object.kind === "player");
            if (existing) return existing.entity;

            initializer.StatePlayer("on", 0.5, 0.5);
            return initializer.player;
        },

        StartWall(name, x, y, z) {
            const label = requireName(name);
            requirePosition(x, y, z);
            return initializer.PlaceWall(x, y, z, 4, 2, 0.5, label);
        },

        StartGround(name = "Piso adicional", width = 50, depth = 50) {
            const label = requireName(name);
            if (!Number.isFinite(width) || !Number.isFinite(depth) || width <= 0 || depth <= 0) {
                throw new Error("A largura e a profundidade do chão precisam ser positivas.");
            }
            return initializer.StateGround(width, depth, label, false);
        },

        StartCamera(name, x = 0, y = 2, z = 5) {
            const label = requireName(name);
            requirePosition(x, y, z);
            const existing = initializer.FindCodeSetupDuplicate(label);
            if (existing) return existing.entity;
            return initializer.AddCamera({
                label,
                type: "static",
                x,
                y,
                z,
                lookAtX: 0,
                lookAtY: 1,
                lookAtZ: 0
            });
        },

        StartLight(name, x = 10, y = 15, z = 10) {
            const label = requireName(name);
            requirePosition(x, y, z);
            return initializer.PlaceLight(
                x,
                y,
                z,
                0.8,
                initializer.projectSettings.shadowResolution,
                16,
                -0.0001,
                "directional",
                label
            );
        },

        StartStair(name, x = 0, width = 3, steps = 6) {
            const label = requireName(name);
            if (!Number.isFinite(x) || !Number.isFinite(width) || width <= 0
                || !Number.isInteger(steps) || steps < 1) {
                throw new Error("A escada precisa de uma posição, largura positiva e quantidade inteira de degraus.");
            }
            return initializer.PlaceStair(steps, 0.25, 0.5, x, width, label);
        },

        StartBox(name, x, y, z, width = 1, height = 1, depth = 1) {
            const label = requireName(name);
            requirePosition(x, y, z);
            if (![width, height, depth].every((size) => Number.isFinite(size) && size > 0)) {
                throw new Error("As dimensões do cubo precisam ser positivas.");
            }
            return initializer.AddGeometry({
                label,
                geometryType: "box",
                x,
                y,
                z,
                width,
                height,
                depth,
                rotationX: 0,
                rotationY: 0,
                rotationZ: 0,
                scaleX: 1,
                scaleY: 1,
                scaleZ: 1
            });
        },

        StartSphere(name, x, y, z, radius = 1) {
            const label = requireName(name);
            requirePosition(x, y, z);
            if (!Number.isFinite(radius) || radius <= 0) {
                throw new Error("O raio da esfera precisa ser positivo.");
            }
            return initializer.AddGeometry({
                label,
                geometryType: "sphere",
                x,
                y,
                z,
                radius,
                widthSegments: 16,
                heightSegments: 12,
                rotationX: 0,
                rotationY: 0,
                rotationZ: 0,
                scaleX: 1,
                scaleY: 1,
                scaleZ: 1
            });
        }
    };
}
