import * as THREE from "three";
import { startEditor } from "./startEditor.js";

function showStartupError(error) {
    console.error("Não foi possível iniciar o editor:", error);
    const message = document.createElement("div");
    message.className = "startup-error";
    message.textContent = `Não foi possível iniciar o editor: ${error.message}`;
    document.body.appendChild(message);
}

export function world(buildWorld = () => {}) {
    const canvas = document.getElementById("game");
    const scene = new THREE.Scene();

    return startEditor({
        canvas,
        scene,
        width: window.innerWidth,
        height: window.innerHeight,
        setupScene(initializer, beginnerTools) {
            return buildWorld({ ...beginnerTools, initializer });
        }
    }).catch((error) => {
        showStartupError(error);
    });
}
