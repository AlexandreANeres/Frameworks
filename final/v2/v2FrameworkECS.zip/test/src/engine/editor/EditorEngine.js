import * as THREE from "three";
import { TransformControls } from "three/addons/controls/TransformControls.js";
import { Mesh } from "../../components/Mesh.js";
import { Transform } from "../../components/Transform.js";
import { CapsuleCollider } from "../../components/CapsuleCollider.js";
import { EditorWorld } from "./ecs/EditorWorld.js";
import { EditorObject } from "./components/EditorObject.js";
import { EditorSelectionSystem } from "./systems/EditorSelectionSystem.js";
import { EditorTransformSystem } from "./systems/EditorTransformSystem.js";
import { EditorMeshCollisionSystem } from "./systems/EditorMeshCollisionSystem.js";
import { createEditorGeometry, createEditorPrimitive } from "./createEditorPrimitive.js";

const selectableKinds = new Set(["player", "ground", "wall", "stair", "geometry"]);

function getMeshMaterials(mesh) {
    const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    return materials.filter(Boolean);
}

function getEditableMaterialType(material) {
    if (material.isMeshStandardMaterial) return "standard";
    if (material.isMeshPhongMaterial) return "phong";
    if (material.isMeshLambertMaterial) return "lambert";
    if (material.isMeshBasicMaterial) return "basic";
    return undefined;
}

function createEditableMaterial(type, source) {
    const parameters = {
        color: source.color?.getHex() ?? 0xffffff,
        map: source.map ?? null,
        opacity: source.opacity ?? 1,
        transparent: source.transparent ?? false,
        wireframe: source.wireframe ?? false,
        side: source.side ?? THREE.FrontSide
    };

    let material;
    if (type === "standard") {
        material = new THREE.MeshStandardMaterial({
            ...parameters,
            metalness: source.metalness ?? 0,
            roughness: source.roughness ?? 0.5,
            emissive: source.emissive?.getHex() ?? 0x000000,
            emissiveIntensity: source.emissiveIntensity ?? 1
        });
    } else if (type === "phong") {
        material = new THREE.MeshPhongMaterial({
            ...parameters,
            shininess: source.shininess ?? 30,
            emissive: source.emissive?.getHex() ?? 0x000000,
            emissiveIntensity: source.emissiveIntensity ?? 1
        });
    } else if (type === "lambert") {
        material = new THREE.MeshLambertMaterial({
            ...parameters,
            emissive: source.emissive?.getHex() ?? 0x000000,
            emissiveIntensity: source.emissiveIntensity ?? 1
        });
    } else {
        material = new THREE.MeshBasicMaterial(parameters);
    }

    material.name = source.name;
    material.depthWrite = source.depthWrite ?? !material.transparent;
    material.alphaTest = source.alphaTest ?? 0;
    return material;
}

export class EditorEngine {
    constructor({
        gameWorld,
        scene,
        canvas,
        camera,
        objectRecords,
        selectionTools,
        selectionName,
        materialEditor,
        transformModeButtons,
        onTransformDragging
    }) {
        this.gameWorld = gameWorld;
        this.scene = scene;
        this.canvas = canvas;
        this.objectRecords = objectRecords;
        this.materialEditor = materialEditor;
        this.materialEditorObject = undefined;
        this.textureLoadRequest = 0;
        this.mode = "edit";
        this.cameraControlMode = "editor-free";
        this.transformModeButtons = transformModeButtons;
        this.gameToEditorEntity = new Map();
        this.world = new EditorWorld();
        this.onTransformDragging = onTransformDragging;

        this.transformControls = new TransformControls(camera, canvas);
        const transformHelper = this.transformControls.getHelper();
        const fadedMaterials = new Set();
        transformHelper.traverse((object) => {
            const materials = Array.isArray(object.material)
                ? object.material
                : object.material ? [object.material] : [];
            for (const material of materials) {
                if (fadedMaterials.has(material)) continue;
                fadedMaterials.add(material);
                material.opacity *= 0.68;
                material.transparent = true;
                material.depthWrite = false;
            }
        });
        this.scene.add(transformHelper);

        this.selectionSystem = new EditorSelectionSystem(
            canvas,
            () => this.transformControls.camera,
            () => this.mode === "edit",
            this.transformControls,
            selectionTools,
            selectionName
        );
        this.selectionSystem.editorWorld = this.world;
        this.transformSystem = new EditorTransformSystem();
        this.collisionSystem = new EditorMeshCollisionSystem(() => this.mode === "play");
        this.world.addSystem(this.selectionSystem);
        this.world.addSystem(this.transformSystem);
        this.world.addSystem(this.collisionSystem);
        this.bindMaterialEditor();

        this.transformControls.addEventListener("objectChange", () => {
            const selected = this.selectionSystem.getSelectedEntity();
            if (selected !== undefined) this.transformSystem.markDirty(selected);
        });
        this.transformControls.addEventListener("dragging-changed", (event) => {
            if (this.mode === "edit") {
                this.onTransformDragging?.(event.value, this.cameraControlMode);
            }
        });

        for (const button of transformModeButtons) {
            button.addEventListener("click", () => {
                this.setTransformMode(button.dataset.transformMode);
                for (const modeButton of transformModeButtons) {
                    modeButton.classList.toggle("active", modeButton === button);
                }
            });
        }

        this.syncObjects();
        this.setTransformMode("translate");
    }

    update(gameWorld, deltaTime) {
        this.syncObjects(gameWorld);
        this.world.update(gameWorld, deltaTime);
        this.refreshMaterialEditor();
        this.updateTransformAxes();
    }

    syncObjects(gameWorld = this.gameWorld) {
        const seenEntities = new Set();
        for (const record of this.objectRecords) {
            if (!selectableKinds.has(record.kind)) continue;
            const gameEntities = record.entities ?? [record.entity];

            for (const gameEntity of gameEntities) {
                if (gameEntity === undefined) continue;
                const meshComponent = gameWorld.getComponent(gameEntity, Mesh);
                if (!meshComponent?.mesh) continue;
                seenEntities.add(gameEntity);

                const existing = this.gameToEditorEntity.get(gameEntity);
                if (existing !== undefined) {
                    const editorObject = this.world.getComponent(existing, EditorObject);
                    editorObject.objectRecord = record;
                    editorObject.mesh = meshComponent.mesh;
                    if (editorObject.geometry !== meshComponent.mesh.geometry) {
                        editorObject.refreshCollisionGeometry();
                    }
                    if (record.kind === "player") {
                        editorObject.baseCapsuleRadius = record.values.horizontalLength;
                        editorObject.baseCapsuleHeight = record.values.verticalLength * 2;
                        editorObject.syncCapsuleCollider(
                            gameWorld.getComponent(gameEntity, CapsuleCollider)
                        );
                    }
                    continue;
                }

                const editorEntity = this.world.createEntity();
                this.world.addComponent(
                    editorEntity,
                    new EditorObject(gameEntity, record, meshComponent.mesh)
                );
                this.gameToEditorEntity.set(gameEntity, editorEntity);
            }
        }

        for (const [gameEntity, editorEntity] of this.gameToEditorEntity) {
            if (seenEntities.has(gameEntity)) continue;
            if (this.selectionSystem.getSelectedEntity() === editorEntity) {
                this.selectionSystem.select(undefined);
            }
            this.world.destroyEntity(editorEntity);
            this.gameToEditorEntity.delete(gameEntity);
        }

        this.selectionSystem.refreshSelectionTools();
    }

    createPrimitive(values) {
        const record = createEditorPrimitive(this.gameWorld, this.scene, values);
        this.objectRecords.push(record);
        this.syncObjects();
        return record;
    }

    updatePrimitive(objectRecord, values) {
        const transform = this.gameWorld.getComponent(objectRecord.entity, Transform);
        const meshComponent = this.gameWorld.getComponent(objectRecord.entity, Mesh);
        const mesh = meshComponent.mesh;

        mesh.geometry.dispose();
        mesh.geometry = createEditorGeometry(values);
        mesh.position.set(values.x, values.y, values.z);
        mesh.rotation.set(values.rotationX, values.rotationY, values.rotationZ);
        mesh.scale.set(values.scaleX, values.scaleY, values.scaleZ);

        transform.x = values.x;
        transform.y = values.y;
        transform.z = values.z;
        transform.rotX = values.rotationX;
        transform.rotY = values.rotationY;
        transform.rotZ = values.rotationZ;
        transform.scaleX = values.scaleX;
        transform.scaleY = values.scaleY;
        transform.scaleZ = values.scaleZ;

        objectRecord.label = values.label;
        objectRecord.values = { ...values };
        this.markGameEntityDirty(objectRecord.entity);
        this.syncObjects();
    }

    markGameEntityDirty(gameEntity) {
        const editorEntity = this.gameToEditorEntity.get(gameEntity);
        if (editorEntity !== undefined) this.transformSystem.markDirty(editorEntity);
    }

    syncPlayerCollider(gameEntity) {
        const editorEntity = this.gameToEditorEntity.get(gameEntity);
        if (editorEntity === undefined) return;

        const editorObject = this.world.getComponent(editorEntity, EditorObject);
        const values = editorObject.objectRecord.values;
        editorObject.baseCapsuleRadius = values.horizontalLength;
        editorObject.baseCapsuleHeight = values.verticalLength * 2;
        editorObject.syncCapsuleCollider(
            this.gameWorld.getComponent(gameEntity, CapsuleCollider)
        );
    }

    serializeObject(record) {
        const gameEntities = record.entities ?? [record.entity];
        return gameEntities.map((gameEntity) => {
            const mesh = this.gameWorld.getComponent(gameEntity, Mesh)?.mesh;
            if (!mesh) return null;

            const materials = getMeshMaterials(mesh).map((material) => ({
                type: getEditableMaterialType(material) ?? "standard",
                color: material.color?.getHexString() ?? "ffffff",
                metalness: material.metalness ?? 0,
                roughness: material.roughness ?? 0.5,
                shininess: material.shininess ?? 30,
                emissive: material.emissive?.getHexString() ?? "000000",
                emissiveIntensity: material.emissiveIntensity ?? 1,
                opacity: material.opacity ?? 1,
                transparent: material.transparent ?? false,
                wireframe: material.wireframe ?? false,
                side: material.side === THREE.DoubleSide
                    ? "double"
                    : material.side === THREE.BackSide ? "back" : "front",
                textureSource: record.values.textureSource ?? null
            }));

            return {
                castShadow: mesh.castShadow,
                transform: {
                    position: mesh.position.toArray(),
                    rotation: mesh.rotation.toArray(),
                    scale: mesh.scale.toArray()
                },
                materials
            };
        }).filter(Boolean);
    }

    restoreObjectState(record, snapshots) {
        if (!Array.isArray(snapshots)) return;
        const gameEntities = record.entities ?? [record.entity];

        snapshots.forEach((snapshot, index) => {
            const gameEntity = gameEntities[index];
            if (gameEntity === undefined) return;
            const mesh = this.gameWorld.getComponent(gameEntity, Mesh)?.mesh;
            const transform = this.gameWorld.getComponent(gameEntity, Transform);
            if (!mesh || !transform) return;

            if (snapshot.transform) {
                const { position, rotation, scale } = snapshot.transform;
                if (position?.length === 3) mesh.position.fromArray(position);
                if (rotation?.length >= 3) mesh.rotation.fromArray(rotation);
                if (scale?.length === 3) mesh.scale.fromArray(scale);
                transform.x = mesh.position.x;
                transform.y = mesh.position.y;
                transform.z = mesh.position.z;
                transform.rotX = mesh.rotation.x;
                transform.rotY = mesh.rotation.y;
                transform.rotZ = mesh.rotation.z;
                transform.scaleX = mesh.scale.x;
                transform.scaleY = mesh.scale.y;
                transform.scaleZ = mesh.scale.z;
            }

            if (snapshot.castShadow !== undefined) mesh.castShadow = snapshot.castShadow;
            if (Array.isArray(snapshot.materials) && snapshot.materials.length) {
                const oldMaterials = getMeshMaterials(mesh);
                const restoredMaterials = snapshot.materials.map((snapshotMaterial) => {
                    const material = createEditableMaterial(snapshotMaterial.type, {
                        color: new THREE.Color(`#${snapshotMaterial.color ?? "ffffff"}`),
                        emissive: new THREE.Color(`#${snapshotMaterial.emissive ?? "000000"}`),
                        metalness: snapshotMaterial.metalness,
                        roughness: snapshotMaterial.roughness,
                        shininess: snapshotMaterial.shininess,
                        emissiveIntensity: snapshotMaterial.emissiveIntensity,
                        opacity: snapshotMaterial.opacity,
                        transparent: snapshotMaterial.transparent,
                        wireframe: snapshotMaterial.wireframe,
                        side: {
                            front: THREE.FrontSide,
                            double: THREE.DoubleSide,
                            back: THREE.BackSide
                        }[snapshotMaterial.side] ?? THREE.FrontSide,
                        map: null
                    });
                    if (snapshotMaterial.textureSource) {
                        this.restoreTexture(material, snapshotMaterial.textureSource);
                    }
                    return material;
                });
                mesh.material = Array.isArray(mesh.material)
                    ? restoredMaterials
                    : restoredMaterials[0];
                for (const material of oldMaterials) {
                    material.map?.dispose();
                    material.dispose();
                }
            }

            const editorEntity = this.gameToEditorEntity.get(gameEntity);
            if (editorEntity !== undefined) this.transformSystem.markDirty(editorEntity);
        });
    }

    restoreTexture(material, source) {
        const loader = new THREE.TextureLoader();
        loader.load(
            source,
            (texture) => {
                texture.colorSpace = THREE.SRGBColorSpace;
                material.map = texture;
                material.needsUpdate = true;
            },
            undefined,
            () => {
                if (this.materialStatus) {
                    this.materialStatus.textContent =
                        "Não foi possível restaurar uma textura deste projeto.";
                }
            }
        );
    }

    unregisterGameEntity(gameEntity) {
        const editorEntity = this.gameToEditorEntity.get(gameEntity);
        if (editorEntity === undefined) return;
        if (this.selectionSystem.getSelectedEntity() === editorEntity) {
            this.selectionSystem.select(undefined);
        }
        this.world.destroyEntity(editorEntity);
        this.gameToEditorEntity.delete(gameEntity);
    }

    setCamera(camera, controlMode = this.cameraControlMode) {
        if (!camera) return;
        this.transformControls.camera = camera;
        this.cameraControlMode = controlMode;
    }

    setMode(mode) {
        this.mode = mode;
        this.transformControls.enabled = mode === "edit";
        if (mode === "edit") {
            const selected = this.selectionSystem.getSelectedObject();
            if (selected) this.transformControls.attach(selected.mesh);
        } else {
            this.transformControls.detach();
        }
        this.selectionSystem.refreshSelectionTools();
    }

    setTransformMode(mode) {
        this.transformControls.setMode(mode);
        for (const button of this.transformModeButtons) {
            button.classList.toggle("active", button.dataset.transformMode === mode);
        }
        this.updateTransformAxes();
    }

    updateTransformAxes() {
        const selected = this.selectionSystem.getSelectedObject();
        const playerRotation = selected?.objectRecord.kind === "player"
            && this.transformControls.mode === "rotate";
        this.transformControls.showX = !playerRotation;
        this.transformControls.showY = true;
        this.transformControls.showZ = !playerRotation;
    }

    bindMaterialEditor() {
        this.materialTypeSelect = this.materialEditor.querySelector("[data-material-type]");
        this.materialStatus = this.materialEditor.querySelector(".editor-material-status");

        this.materialTypeSelect.addEventListener("change", () => {
            this.replaceSelectedMaterialType(this.materialTypeSelect.value);
        });
        this.materialEditor.addEventListener("input", (event) => {
            if (event.target.matches("[data-material-property]:not(select)")) {
                this.applyMaterialProperty(event.target);
            }
        });
        this.materialEditor.addEventListener("change", (event) => {
            if (event.target.matches("select[data-material-property]")) {
                this.applyMaterialProperty(event.target);
            }
            if (event.target.matches("[data-texture-file]")) {
                this.loadTextureFromFile(event.target.files?.[0]);
                event.target.value = "";
            }
        });
        this.materialEditor.querySelector("[data-texture-apply]").addEventListener(
            "click",
            () => this.loadTextureFromUrl()
        );
        this.materialEditor.querySelector("[data-texture-url]").addEventListener(
            "keydown",
            (event) => {
                if (event.key === "Enter") {
                    event.preventDefault();
                    this.loadTextureFromUrl();
                }
            }
        );
        this.materialEditor.querySelector("[data-texture-remove]").addEventListener(
            "click",
            () => this.removeSelectedTexture()
        );
    }

    refreshMaterialEditor() {
        const selected = this.selectionSystem.getSelectedObject();
        if (selected === this.materialEditorObject) return;

        this.textureLoadRequest++;
        this.materialEditorObject = selected;
        this.materialEditor.hidden = !selected;
        if (selected) {
            this.updateMaterialEditorValues(selected);
        } else {
            this.materialStatus.textContent = "";
        }
    }

    updateMaterialEditorValues(editorObject) {
        const materials = getMeshMaterials(editorObject.mesh);
        const material = materials[0];
        if (!material) return;

        const materialType = getEditableMaterialType(material);
        const type = materialType ?? "standard";
        this.materialTypeSelect.value = type;
        const values = {
            color: `#${material.color?.getHexString() ?? "ffffff"}`,
            metalness: material.metalness ?? 0,
            roughness: material.roughness ?? 0.5,
            shininess: material.shininess ?? 30,
            emissive: `#${material.emissive?.getHexString() ?? "000000"}`,
            emissiveIntensity: material.emissiveIntensity ?? 1,
            opacity: material.opacity ?? 1,
            transparent: material.transparent ?? false,
            wireframe: material.wireframe ?? false,
            castShadow: editorObject.mesh.castShadow,
            side: material.side === THREE.DoubleSide
                ? "double"
                : material.side === THREE.BackSide ? "back" : "front"
        };

        for (const [property, value] of Object.entries(values)) {
            const input = this.materialEditor.querySelector(
                `[data-material-property="${property}"]`
            );
            if (input.type === "checkbox") {
                input.checked = value;
            } else {
                input.value = String(value);
            }

            const output = this.materialEditor.querySelector(
                `[data-material-output="${property}"]`
            );
            if (output) output.value = Number(value).toFixed(2);
        }

        for (const group of this.materialEditor.querySelectorAll("[data-material-types]")) {
            group.hidden = !group.dataset.materialTypes.split(/\s+/).includes(type);
        }
        this.materialEditor.querySelector("[data-texture-remove]").disabled =
            !materials.some((candidate) => candidate.map);
        this.materialStatus.textContent = materials.some((candidate) => candidate.map)
            ? "Textura aplicada."
            : materialType ? "" : "Será convertido para Standard ao editar.";
    }

    replaceSelectedMaterialType(type) {
        const editorObject = this.selectionSystem.getSelectedObject();
        if (!editorObject) return;

        const currentMaterials = getMeshMaterials(editorObject.mesh);
        if (!currentMaterials.length) return;
        const updatedMaterials = currentMaterials.map((material) =>
            createEditableMaterial(type, material)
        );
        editorObject.mesh.material = Array.isArray(editorObject.mesh.material)
            ? updatedMaterials
            : updatedMaterials[0];
        for (const material of currentMaterials) material.dispose();
        this.updateMaterialEditorValues(editorObject);
    }

    applyMaterialProperty(input) {
        const editorObject = this.selectionSystem.getSelectedObject();
        if (!editorObject) return;

        const property = input.dataset.materialProperty;
        const value = input.type === "checkbox" ? input.checked : input.value;
        if (property === "castShadow") {
            editorObject.mesh.castShadow = value;
            if (editorObject.objectRecord.kind === "player") {
                editorObject.objectRecord.values.shadows = value;
            } else {
                editorObject.objectRecord.values.castShadow = value;
            }
            this.updateMaterialEditorValues(editorObject);
            return;
        }

        const type = this.materialTypeSelect.value;
        let materials = getMeshMaterials(editorObject.mesh);
        if (materials.some((material) => getEditableMaterialType(material) !== type)) {
            this.replaceSelectedMaterialType(type);
            materials = getMeshMaterials(editorObject.mesh);
        }

        for (const material of materials) {
            if (property === "color") {
                material.color?.set(value);
            } else if (property === "emissive") {
                material.emissive?.set(value);
            } else if (property === "side") {
                material.side = {
                    front: THREE.FrontSide,
                    double: THREE.DoubleSide,
                    back: THREE.BackSide
                }[value];
                material.needsUpdate = true;
            } else if (property === "transparent") {
                material.transparent = value;
                material.depthWrite = !value;
                material.needsUpdate = true;
            } else if (property === "wireframe") {
                material.wireframe = value;
                material.needsUpdate = true;
            } else if (property === "opacity") {
                material.opacity = Number(value);
                if (material.opacity < 1) {
                    material.transparent = true;
                    material.depthWrite = false;
                }
            } else if (property in material) {
                material[property] = Number(value);
            }
        }

        this.updateMaterialEditorValues(editorObject);
    }

    loadTextureFromFile(file) {
        if (!file) return;
        if (!file.type.startsWith("image/")) {
            this.materialStatus.textContent = "Selecione um arquivo de imagem.";
            return;
        }

        const reader = new FileReader();
        reader.onload = () => this.loadTexture(String(reader.result));
        reader.onerror = () => {
            this.materialStatus.textContent = "Não foi possível ler o arquivo de imagem.";
        };
        reader.readAsDataURL(file);
    }

    loadTextureFromUrl() {
        const value = this.materialEditor.querySelector("[data-texture-url]").value.trim();
        if (!value) {
            this.materialStatus.textContent = "Informe a URL de uma imagem.";
            return;
        }

        let url;
        try {
            url = new URL(value, window.location.href);
        } catch {
            this.materialStatus.textContent = "A URL da imagem não é válida.";
            return;
        }
        if (!["http:", "https:"].includes(url.protocol)) {
            this.materialStatus.textContent = "Use uma URL HTTP ou HTTPS para a imagem.";
            return;
        }

        this.loadTexture(url.href);
    }

    loadTexture(url, objectUrlToRevoke) {
        const editorObject = this.selectionSystem.getSelectedObject();
        if (!editorObject) {
            if (objectUrlToRevoke) URL.revokeObjectURL(objectUrlToRevoke);
            this.materialStatus.textContent = "Selecione um objeto antes de aplicar a textura.";
            return;
        }

        const type = this.materialTypeSelect.value;
        if (getMeshMaterials(editorObject.mesh).some(
            (material) => getEditableMaterialType(material) !== type
        )) {
            this.replaceSelectedMaterialType(type);
        }

        const request = ++this.textureLoadRequest;
        this.materialStatus.textContent = "Carregando textura...";
        const loader = new THREE.TextureLoader();
        let texture;
        const releaseObjectUrl = () => {
            if (objectUrlToRevoke) URL.revokeObjectURL(objectUrlToRevoke);
        };

        texture = loader.load(
            url,
            (loadedTexture) => {
                if (request !== this.textureLoadRequest
                    || this.selectionSystem.getSelectedObject() !== editorObject) {
                    loadedTexture.dispose();
                    releaseObjectUrl();
                    return;
                }

                loadedTexture.colorSpace = THREE.SRGBColorSpace;
                const materials = getMeshMaterials(editorObject.mesh);
                const oldTextures = new Set(
                    materials.map((material) => material.map).filter(Boolean)
                );
                for (const material of materials) {
                    material.map = loadedTexture;
                    material.needsUpdate = true;
                }
                editorObject.objectRecord.values.textureSource = url;
                for (const oldTexture of oldTextures) oldTexture.dispose();

                this.updateMaterialEditorValues(editorObject);
                this.materialStatus.textContent = "Textura aplicada.";
                releaseObjectUrl();
            },
            undefined,
            () => {
                if (request === this.textureLoadRequest
                    && this.selectionSystem.getSelectedObject() === editorObject) {
                    this.materialStatus.textContent =
                        "Não foi possível carregar a imagem. Verifique a URL, o formato e o CORS.";
                }
                texture?.dispose();
                releaseObjectUrl();
            }
        );
    }

    removeSelectedTexture() {
        const editorObject = this.selectionSystem.getSelectedObject();
        if (!editorObject) return;

        const textures = new Set(
            getMeshMaterials(editorObject.mesh)
                .map((material) => material.map)
                .filter(Boolean)
        );
        for (const material of getMeshMaterials(editorObject.mesh)) {
            material.map = null;
            material.needsUpdate = true;
        }
        delete editorObject.objectRecord.values.textureSource;
        for (const texture of textures) texture.dispose();
        this.materialEditor.querySelector("[data-texture-remove]").disabled = true;
        this.materialStatus.textContent = "Textura removida.";
    }

    dispose() {
        this.textureLoadRequest++;
        this.transformControls.dispose();
        this.scene.remove(this.transformControls.getHelper());
        this.gameToEditorEntity.clear();
        this.world.entities.clear();
        this.world.components.clear();
        this.world.systems.length = 0;
    }
}
