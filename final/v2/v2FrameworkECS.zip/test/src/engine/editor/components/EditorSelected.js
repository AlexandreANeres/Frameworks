export class EditorSelected {}
