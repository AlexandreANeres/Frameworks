import { Octree } from "three/addons/math/Octree.js";

export class EditorObject {
    constructor(gameEntity, objectRecord, mesh) {
        this.gameEntity = gameEntity;
        this.objectRecord = objectRecord;
        this.mesh = mesh;
        this.geometry = mesh.geometry;
        this.collisionOctree = undefined;
        this.baseCapsuleRadius = objectRecord.kind === "player"
            ? objectRecord.values.horizontalLength
            : undefined;
        this.baseCapsuleHeight = objectRecord.kind === "player"
            ? objectRecord.values.verticalLength * 2
            : undefined;
        this.refreshCollisionGeometry();
    }

    refreshCollisionGeometry() {
        this.geometry = this.mesh.geometry;
        if (this.objectRecord.kind === "geometry") {
            this.mesh.updateWorldMatrix(true, false);
            this.collisionOctree = new Octree().fromGraphNode(this.mesh);
        } else {
            this.collisionOctree = undefined;
        }
    }

    syncCapsuleCollider(collider) {
        if (!collider || this.objectRecord.kind !== "player") return;

        collider.radius = this.baseCapsuleRadius
            * Math.max(Math.abs(this.mesh.scale.x), Math.abs(this.mesh.scale.z));
        collider.height = this.baseCapsuleHeight * Math.abs(this.mesh.scale.y);
    }
}
