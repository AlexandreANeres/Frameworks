import * as THREE from "three";
import { Transform } from "../../components/Transform.js";
import { Mesh } from "../../components/Mesh.js";
import { StaticBody } from "../../components/StaticBody.js";

function segments(value, minimum = 3) {
    return Math.max(minimum, Math.floor(Number(value) || minimum));
}

export function createEditorGeometry(values) {
    let geometry;
    switch (values.geometryType) {
        case "box":
            geometry = new THREE.BoxGeometry(values.width, values.height, values.depth);
            break;
        case "sphere":
            geometry = new THREE.SphereGeometry(
                values.radius,
                segments(values.widthSegments, 3),
                segments(values.heightSegments, 2)
            );
            break;
        case "cylinder":
            geometry = new THREE.CylinderGeometry(
                values.radiusTop,
                values.radiusBottom,
                values.height,
                segments(values.radialSegments)
            );
            break;
        case "cone":
            geometry = new THREE.ConeGeometry(
                values.radius,
                values.height,
                segments(values.radialSegments)
            );
            break;
        case "capsule":
            geometry = new THREE.CapsuleGeometry(
                values.radius,
                values.length,
                segments(values.capSegments, 1),
                segments(values.radialSegments)
            );
            break;
        case "torus":
            geometry = new THREE.TorusGeometry(
                values.radius,
                values.tube,
                segments(values.radialSegments),
                segments(values.tubularSegments)
            );
            break;
        case "torusKnot":
            geometry = new THREE.TorusKnotGeometry(
                values.radius,
                values.tube,
                segments(values.tubularSegments),
                segments(values.radialSegments),
                segments(values.p, 1),
                segments(values.q, 1)
            );
            break;
        case "ring":
            geometry = new THREE.RingGeometry(
                values.innerRadius,
                values.outerRadius,
                segments(values.thetaSegments),
                segments(values.phiSegments, 1)
            );
            break;
        case "tube": {
            const curve = new THREE.CatmullRomCurve3([
                new THREE.Vector3(values.startX, values.startY, values.startZ),
                new THREE.Vector3(values.control1X, values.control1Y, values.control1Z),
                new THREE.Vector3(values.control2X, values.control2Y, values.control2Z),
                new THREE.Vector3(values.endX, values.endY, values.endZ)
            ]);
            geometry = new THREE.TubeGeometry(
                curve,
                segments(values.tubularSegments),
                values.radius,
                segments(values.radialSegments),
                false
            );
            break;
        }
        default:
            throw new Error(`Unknown editor geometry type: ${values.geometryType}`);
    }

    geometry.computeBoundingBox();
    const center = geometry.boundingBox.getCenter(new THREE.Vector3());
    geometry.translate(-center.x, -center.y, -center.z);
    return geometry;
}

export function createEditorPrimitive(world, scene, values) {
    const entity = world.createEntity();
    const geometry = createEditorGeometry(values);
    const material = new THREE.MeshStandardMaterial({
        color: 0x7dd3fc,
        metalness: 0,
        roughness: 0.75
    });
    const mesh = new THREE.Mesh(geometry, material);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.position.set(values.x, values.y, values.z);
    mesh.rotation.set(values.rotationX, values.rotationY, values.rotationZ);
    mesh.scale.set(values.scaleX, values.scaleY, values.scaleZ);
    scene.add(mesh);

    const transform = new Transform(
        values.x,
        values.y,
        values.z,
        values.rotationX,
        values.rotationY,
        values.rotationZ
    );
    transform.scaleX = values.scaleX;
    transform.scaleY = values.scaleY;
    transform.scaleZ = values.scaleZ;
    world.addComponent(entity, transform);
    world.addComponent(entity, new Mesh(mesh));
    world.addComponent(entity, new StaticBody());

    return {
        kind: "geometry",
        label: values.label,
        entity,
        permanent: false,
        values: { ...values }
    };
}
