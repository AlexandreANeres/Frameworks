import * as THREE from "three";
import { EditorSystem } from "../ecs/EditorSystem.js";
import { EditorObject } from "../components/EditorObject.js";
import { Transform } from "../../../components/Transform.js";
import { ColliderAABB } from "../../../components/ColliderAABB.js";
import { CapsuleCollider } from "../../../components/CapsuleCollider.js";

export class EditorTransformSystem extends EditorSystem {
    constructor() {
        super();
        this.dirtyEntities = new Set();
    }

    markDirty(entity) {
        this.dirtyEntities.add(entity);
    }

    update(editorWorld, gameWorld) {
        for (const editorEntity of this.dirtyEntities) {
            const editorObject = editorWorld.getComponent(editorEntity, EditorObject);
            if (!editorObject) continue;

            const { gameEntity, mesh, objectRecord } = editorObject;
            const transform = gameWorld.getComponent(gameEntity, Transform);
            if (!transform) continue;

            transform.x = mesh.position.x;
            transform.y = mesh.position.y;
            transform.z = mesh.position.z;
            transform.rotX = mesh.rotation.x;
            transform.rotY = mesh.rotation.y;
            transform.rotZ = mesh.rotation.z;
            transform.scaleX = mesh.scale.x;
            transform.scaleY = mesh.scale.y;
            transform.scaleZ = mesh.scale.z;

            const capsule = gameWorld.getComponent(gameEntity, CapsuleCollider);
            editorObject.syncCapsuleCollider(capsule);

            const collider = gameWorld.getComponent(gameEntity, ColliderAABB);
            if (collider) {
                mesh.updateWorldMatrix(true, false);
                const bounds = new THREE.Box3().setFromObject(mesh);
                const size = bounds.getSize(new THREE.Vector3());
                const minimumHalfSize = objectRecord.kind === "ground" ? 0.009 : 0.001;
                collider.halfX = Math.max(size.x / 2, minimumHalfSize);
                collider.halfY = Math.max(size.y / 2, minimumHalfSize);
                collider.halfZ = Math.max(size.z / 2, minimumHalfSize);
            }

            objectRecord.values = {
                ...objectRecord.values,
                x: transform.x,
                y: transform.y,
                z: transform.z,
                rotationX: transform.rotX,
                rotationY: transform.rotY,
                rotationZ: transform.rotZ,
                scaleX: transform.scaleX,
                scaleY: transform.scaleY,
                scaleZ: transform.scaleZ
            };
            editorObject.refreshCollisionGeometry();
        }

        this.dirtyEntities.clear();
    }
}
