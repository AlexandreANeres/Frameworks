import { Capsule } from "three/addons/math/Capsule.js";
import { Vector3 } from "three";
import { EditorSystem } from "../ecs/EditorSystem.js";
import { EditorObject } from "../components/EditorObject.js";
import { Query } from "../../../ecs/Query.js";
import { DynamicBody } from "../../../components/DynamicBody.js";
import { Transform } from "../../../components/Transform.js";
import { Velocity } from "../../../components/Velocity.js";
import { CapsuleCollider } from "../../../components/CapsuleCollider.js";
import { Grounded } from "../../../components/Grounded.js";
import { ControllerSettings } from "../../../components/ControllerSetting.js";

export class EditorMeshCollisionSystem extends EditorSystem {
    constructor(isPlaying) {
        super();
        this.isPlaying = isPlaying;
    }

    update(editorWorld, gameWorld) {
        if (!this.isPlaying()) return;

        const players = Query.entitiesWith(
            gameWorld,
            DynamicBody,
            Transform,
            Velocity,
            CapsuleCollider,
            Grounded,
            ControllerSettings
        );
        const colliders = editorWorld.entitiesWith(EditorObject);

        for (const player of players) {
            const transform = gameWorld.getComponent(player, Transform);
            const velocity = gameWorld.getComponent(player, Velocity);
            const capsuleCollider = gameWorld.getComponent(player, CapsuleCollider);
            const grounded = gameWorld.getComponent(player, Grounded);
            const settings = gameWorld.getComponent(player, ControllerSettings);
            const capsule = new Capsule(
                new Vector3(
                    transform.x,
                    transform.y - capsuleCollider.halfHeight,
                    transform.z
                ),
                new Vector3(
                    transform.x,
                    transform.y + capsuleCollider.halfHeight,
                    transform.z
                ),
                capsuleCollider.radius
            );

            for (const editorEntity of colliders) {
                const editorObject = editorWorld.getComponent(editorEntity, EditorObject);
                if (!editorObject.collisionOctree) continue;

                const collision = editorObject.collisionOctree.capsuleIntersect(capsule);
                if (!collision || collision.depth <= 0) continue;

                const normal = collision.normal;
                const correction = normal.clone().multiplyScalar(collision.depth);
                transform.x += correction.x;
                transform.y += correction.y;
                transform.z += correction.z;
                capsule.translate(correction);

                const velocityIntoSurface = velocity.x * normal.x
                    + velocity.y * normal.y
                    + velocity.z * normal.z;
                if (velocityIntoSurface < 0) {
                    velocity.x -= velocityIntoSurface * normal.x;
                    velocity.y -= velocityIntoSurface * normal.y;
                    velocity.z -= velocityIntoSurface * normal.z;
                }

                if (normal.y > grounded.normalY) {
                    grounded.normalX = normal.x;
                    grounded.normalY = normal.y;
                    grounded.normalZ = normal.z;
                    grounded.slopeAngleDeg = Math.acos(
                        Math.max(-1, Math.min(1, normal.y))
                    ) * (180 / Math.PI);
                    grounded.isWalkable = grounded.slopeAngleDeg <= settings.slopeLimitDeg;
                    grounded.isGrounded = grounded.isWalkable;
                }
            }
        }
    }
}
