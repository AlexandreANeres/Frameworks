import * as THREE from "three";
import { EditorSystem } from "../ecs/EditorSystem.js";
import { EditorObject } from "../components/EditorObject.js";
import { EditorSelected } from "../components/EditorSelected.js";

export class EditorSelectionSystem extends EditorSystem {
    constructor(canvas, getCamera, isEditing, transformControls, selectionTools, selectionName) {
        super();
        this.canvas = canvas;
        this.getCamera = getCamera;
        this.isEditing = isEditing;
        this.transformControls = transformControls;
        this.selectionTools = selectionTools;
        this.selectionName = selectionName;
        this.raycaster = new THREE.Raycaster();
        this.pointer = new THREE.Vector2();
        this.editorWorld = undefined;

        canvas.addEventListener("pointerdown", (event) => {
            if (event.button !== 0 || !this.isEditing()
                || this.transformControls.axis != null
                || this.transformControls.dragging
                || !this.editorWorld) return;

            const rect = canvas.getBoundingClientRect();
            this.pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            this.pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
            this.raycaster.setFromCamera(this.pointer, this.getCamera());

            const selectable = this.editorWorld.entitiesWith(EditorObject);
            const meshes = selectable.map((entity) =>
                this.editorWorld.getComponent(entity, EditorObject).mesh
            );
            const hit = this.raycaster.intersectObjects(meshes, true)[0];
            let selectedEntity;
            if (hit) {
                let hitObject = hit.object;
                while (hitObject && selectedEntity === undefined) {
                    selectedEntity = selectable.find((entity) =>
                        this.editorWorld.getComponent(entity, EditorObject).mesh === hitObject
                    );
                    hitObject = hitObject.parent;
                }
            }

            this.select(selectedEntity);
        });
    }

    update(editorWorld) {
        this.editorWorld = editorWorld;
        const selected = this.getSelectedEntity();
        if (selected !== undefined && !editorWorld.entities.has(selected)) {
            this.select(undefined);
        }
    }

    getSelectedEntity() {
        return this.editorWorld?.entitiesWith(EditorSelected)[0];
    }

    getSelectedObject() {
        const selected = this.getSelectedEntity();
        return selected === undefined
            ? undefined
            : this.editorWorld.getComponent(selected, EditorObject);
    }

    select(entity) {
        if (!this.editorWorld) return;
        const current = this.getSelectedEntity();
        if (current === entity) return;
        if (current !== undefined) {
            this.editorWorld.removeComponent(current, EditorSelected);
        }

        const selected = entity === undefined
            ? undefined
            : this.editorWorld.getComponent(entity, EditorObject);
        if (selected) {
            this.editorWorld.addComponent(entity, new EditorSelected());
            this.transformControls.attach(selected.mesh);
        } else {
            this.transformControls.detach();
        }

        this.selectionTools.hidden = !selected || !this.isEditing();
        this.selectionName.textContent = selected?.objectRecord.label ?? "";
    }

    refreshSelectionTools() {
        const selected = this.getSelectedObject();
        this.selectionTools.hidden = !selected || !this.isEditing();
        this.selectionName.textContent = selected?.objectRecord.label ?? "";
    }
}
