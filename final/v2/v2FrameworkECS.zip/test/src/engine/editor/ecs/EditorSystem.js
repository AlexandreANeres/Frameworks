export class EditorSystem {
    update(editorWorld, gameWorld, deltaTime) {}
}
