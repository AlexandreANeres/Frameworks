export class EditorWorld {
    constructor() {
        this.nextEntity = 0;
        this.entities = new Set();
        this.components = new Map();
        this.systems = [];
    }

    createEntity() {
        const entity = this.nextEntity++;
        this.entities.add(entity);
        return entity;
    }

    destroyEntity(entity) {
        this.entities.delete(entity);
        for (const componentMap of this.components.values()) {
            componentMap.delete(entity);
        }
    }

    addComponent(entity, component) {
        const type = component.constructor;
        if (!this.components.has(type)) {
            this.components.set(type, new Map());
        }
        this.components.get(type).set(entity, component);
    }

    removeComponent(entity, componentType) {
        this.components.get(componentType)?.delete(entity);
    }

    getComponent(entity, componentType) {
        return this.components.get(componentType)?.get(entity);
    }

    entitiesWith(...componentTypes) {
        return [...this.entities].filter((entity) =>
            componentTypes.every((componentType) =>
                this.components.get(componentType)?.has(entity)
            )
        );
    }

    addSystem(system) {
        this.systems.push(system);
    }

    update(gameWorld, deltaTime) {
        for (const system of this.systems) {
            if (system.enabled !== false) {
                system.update(this, gameWorld, deltaTime);
            }
        }
    }
}
