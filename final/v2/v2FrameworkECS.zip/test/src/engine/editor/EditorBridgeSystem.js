import { System } from "../../ecs/System.js";

export class EditorBridgeSystem extends System {
    constructor(editorEngine) {
        super();
        this.editorEngine = editorEngine;
    }

    update(gameWorld, deltaTime) {
        this.editorEngine.update(gameWorld, deltaTime);
    }
}
