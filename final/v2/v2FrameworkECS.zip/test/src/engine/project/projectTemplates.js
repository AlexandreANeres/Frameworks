import { hubProjects } from "../../projects/index.js";
import { defaultProjectSettings } from "../../projects/projectData.js";

export { defaultProjectSettings };
export const projectTemplates = hubProjects;

export function createProjectFromTemplate(templateId, name) {
    const template = projectTemplates.find((project) => project.id === templateId);
    if (!template) throw new Error(`Unknown project template: ${templateId}`);

    return {
        ...JSON.parse(JSON.stringify(template)),
        id: crypto.randomUUID(),
        version: 1,
        name: name.trim(),
        template: false,
        templateId: template.id
    };
}
