const projectStartMarker = "/* SCENE_EDITOR_PROJECT_START */";
const projectEndMarker = "/* SCENE_EDITOR_PROJECT_END */";
const supportedKinds = new Set([
    "player",
    "camera",
    "ground",
    "wall",
    "stair",
    "light",
    "ambient",
    "geometry"
]);

function isAssetSource(value) {
    if (typeof value !== "string") return false;
    if (value.startsWith("data:image/")) return true;

    try {
        const url = new URL(value);
        return url.protocol === "http:" || url.protocol === "https:";
    } catch {
        return false;
    }
}

function validateUnitRange(value, description) {
    if (value !== undefined
        && (!Number.isFinite(value) || value < 0 || value > 1)) {
        throw new Error(`${description} precisa estar entre 0 e 1.`);
    }
}

export function validateProject(project) {
    if (!project || typeof project !== "object" || Array.isArray(project)) {
        throw new Error("O arquivo não contém um projeto válido.");
    }
    if (project.version !== 1) {
        throw new Error("A versão deste projeto não é compatível.");
    }
    if (typeof project.id !== "string" || !project.id.trim()) {
        throw new Error("O projeto precisa ter um identificador válido.");
    }
    if (typeof project.name !== "string" || !project.name.trim()) {
        throw new Error("O projeto precisa ter um nome.");
    }
    if (!Array.isArray(project.objects)) {
        throw new Error("O projeto não contém uma lista de objetos válida.");
    }

    const groups = project.groups ?? [];
    if (!Array.isArray(groups)) {
        throw new Error("A lista de conjuntos do projeto é inválida.");
    }

    const groupIds = new Set();
    const groupNames = new Set();
    for (const group of groups) {
        if (!group || typeof group.id !== "string" || !group.id.trim()
            || typeof group.name !== "string" || !group.name.trim()
            || typeof group.collapsed !== "boolean") {
            throw new Error("O projeto contém um conjunto com dados inválidos.");
        }
        const normalizedName = group.name.trim().toLocaleLowerCase();
        if (groupIds.has(group.id) || groupNames.has(normalizedName)) {
            throw new Error("Os nomes e identificadores dos conjuntos precisam ser únicos.");
        }
        groupIds.add(group.id);
        groupNames.add(normalizedName);
    }

    const labels = new Set();
    for (const object of project.objects) {
        if (!object || !supportedKinds.has(object.kind)
            || typeof object.label !== "string"
            || !object.values || typeof object.values !== "object"
            || Array.isArray(object.values)) {
            throw new Error("O projeto contém um objeto com dados inválidos.");
        }
        if (object.kind === "player" && object.permanent !== true) {
            throw new Error(`O objeto essencial "${object.label}" não pode ser removido.`);
        }

        const normalizedLabel = object.label.trim().toLocaleLowerCase();
        if (!normalizedLabel || labels.has(normalizedLabel)) {
            throw new Error("Os nomes dos objetos precisam ser únicos e não vazios.");
        }
        labels.add(normalizedLabel);
        if (object.groupId !== undefined && !groupIds.has(object.groupId)) {
            throw new Error(`O objeto "${object.label}" pertence a um conjunto inexistente.`);
        }

        if (object.kind === "camera" && object.values.type !== undefined
            && !["follow", "firstPerson", "birdseye", "static"].includes(object.values.type)) {
            throw new Error(`O modo da câmera "${object.label}" não é válido.`);
        }

        if (object.kind === "player") {
            validateUnitRange(object.values.capsuleOpacity, "A opacidade da cápsula");
            if (object.values.capsuleColor !== undefined
                && !/^#[0-9a-f]{6}$/i.test(object.values.capsuleColor)) {
                throw new Error(`A cor da cápsula do objeto "${object.label}" não é válida.`);
            }
            for (const key of ["capsuleVisible", "capsuleTransparent"]) {
                if (object.values[key] !== undefined && typeof object.values[key] !== "boolean") {
                    throw new Error(`A configuração "${key}" do objeto "${object.label}" é inválida.`);
                }
            }
        }

        if (object.kind === "ground") {
            if (object.values.materialType !== undefined
                && !["standard", "phong", "lambert", "basic"].includes(object.values.materialType)) {
                throw new Error(`O material do chão "${object.label}" não é válido.`);
            }
            if (object.values.side !== undefined
                && !["front", "double", "back"].includes(object.values.side)) {
                throw new Error(`A configuração dos lados do chão "${object.label}" não é válida.`);
            }
            if (object.values.color !== undefined
                && !/^#[0-9a-f]{6}$/i.test(object.values.color)) {
                throw new Error(`A cor do chão "${object.label}" não é válida.`);
            }
            for (const key of ["metalness", "roughness", "opacity"]) {
                validateUnitRange(object.values[key], `A configuração "${key}" do chão`);
            }
            if (object.values.shininess !== undefined
                && (!Number.isFinite(object.values.shininess)
                    || object.values.shininess < 0 || object.values.shininess > 200)) {
                throw new Error("O brilho Phong do chão precisa estar entre 0 e 200.");
            }
            for (const key of ["transparent", "wireframe", "receiveShadow"]) {
                if (object.values[key] !== undefined && typeof object.values[key] !== "boolean") {
                    throw new Error(`A configuração "${key}" do chão "${object.label}" é inválida.`);
                }
            }
        }

        if (object.values.textureSource
            && !isAssetSource(object.values.textureSource)) {
            throw new Error(`A textura do objeto "${object.label}" não é válida.`);
        }

        if (object.meshes !== undefined) {
            if (!Array.isArray(object.meshes)) {
                throw new Error(`O objeto "${object.label}" contém dados de mesh inválidos.`);
            }
            for (const mesh of object.meshes) {
                if (!mesh || typeof mesh !== "object") {
                    throw new Error(`O objeto "${object.label}" contém dados de mesh inválidos.`);
                }
                if (mesh.materials !== undefined && !Array.isArray(mesh.materials)) {
                    throw new Error(`O objeto "${object.label}" contém materiais inválidos.`);
                }
                if (mesh.material?.textureSource
                    && !isAssetSource(mesh.material.textureSource)) {
                    throw new Error(`A textura do objeto "${object.label}" não é válida.`);
                }
                for (const material of mesh.materials ?? []) {
                    if (!material || !["standard", "phong", "lambert", "basic"].includes(material.type)) {
                        throw new Error(`O objeto "${object.label}" contém um material inválido.`);
                    }
                    if (material.textureSource && !isAssetSource(material.textureSource)) {
                        throw new Error(`A textura do objeto "${object.label}" não é válida.`);
                    }
                }
                const transform = mesh.transform;
                if (transform && (
                    ![transform.position, transform.rotation, transform.scale]
                        .every((values) => Array.isArray(values) && values.length >= 3
                            && values.slice(0, 3).every(Number.isFinite))
                )) {
                    throw new Error(`O objeto "${object.label}" contém uma transformação inválida.`);
                }
            }
        }
    }

    for (const requiredKind of ["player", "camera", "ground", "ambient"]) {
        if (!project.objects.some((object) => object.kind === requiredKind && object.permanent)) {
            throw new Error(`O projeto precisa manter pelo menos um objeto "${requiredKind}".`);
        }
    }

    if (project.skyboxSource && !isAssetSource(project.skyboxSource)) {
        throw new Error("A imagem da skybox não é válida.");
    }
    if (project.settings?.shadowsEnabled !== undefined
        && typeof project.settings.shadowsEnabled !== "boolean") {
        throw new Error("A configuração de sombras precisa ser booleana.");
    }

    const settings = project.settings ?? {};
    for (const [key, min, max] of [
        ["shadowResolution", 128, 4096],
        ["renderDistance", 50, 5000],
        ["cameraFov", 30, 120]
    ]) {
        if (settings[key] !== undefined
            && (!Number.isFinite(settings[key]) || settings[key] < min || settings[key] > max)) {
            throw new Error(`A configuração "${key}" está fora dos limites permitidos.`);
        }
    }

    return JSON.parse(JSON.stringify({ ...project, groups }));
}

export function exportProjectAsMainJs(project) {
    const validatedProject = validateProject(project);
    return [
        "/* Projeto de cena exportado pelo editor. Importe este arquivo pela barra lateral. */",
        projectStartMarker,
        `export default ${JSON.stringify(validatedProject, null, 2)};`,
        projectEndMarker,
        ""
    ].join("\n");
}

export function importProjectFromMainJs(source) {
    if (typeof source !== "string") {
        throw new Error("O arquivo importado precisa ser um arquivo main.js.");
    }

    const start = source.indexOf(projectStartMarker);
    const end = source.indexOf(projectEndMarker, start + projectStartMarker.length);
    if (start < 0 || end < 0) {
        throw new Error("Este main.js não contém dados de projeto exportados pelo editor.");
    }

    const body = source.slice(start + projectStartMarker.length, end).trim();
    const exportIndex = body.indexOf("export default ");
    if (exportIndex < 0) {
        throw new Error("O bloco de dados do main.js está incompleto.");
    }

    const serializedProject = body.slice(exportIndex + "export default ".length)
        .trim()
        .replace(/;\s*$/, "");
    let project;
    try {
        project = JSON.parse(serializedProject);
    } catch {
        throw new Error("Os dados JSON do main.js estão corrompidos.");
    }

    return validateProject(project);
}
