import { validateProject } from "./projectFormat.js";

const databaseName = "scene-editor-projects";
const databaseVersion = 1;

function requestResult(request) {
    return new Promise((resolve, reject) => {
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
    });
}

function transactionResult(transaction) {
    return new Promise((resolve, reject) => {
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(transaction.error);
        transaction.onabort = () => reject(transaction.error ?? new Error("A operação foi cancelada."));
    });
}

export class ProjectStore {
    constructor() {
        this.database = undefined;
    }

    async open() {
        if (this.database) return this.database;
        if (!("indexedDB" in window)) {
            throw new Error("Este navegador não oferece armazenamento local de projetos.");
        }

        const request = indexedDB.open(databaseName, databaseVersion);
        request.onupgradeneeded = () => {
            const database = request.result;
            if (!database.objectStoreNames.contains("projects")) {
                database.createObjectStore("projects", { keyPath: "id" });
            }
            if (!database.objectStoreNames.contains("metadata")) {
                database.createObjectStore("metadata", { keyPath: "key" });
            }
        };
        this.database = await requestResult(request);
        this.database.onversionchange = () => {
            this.database.close();
            this.database = undefined;
        };
        return this.database;
    }

    async seedTemplates(templates) {
        const database = await this.open();
        const transaction = database.transaction("projects", "readwrite");
        const done = transactionResult(transaction);
        const store = transaction.objectStore("projects");
        const results = await Promise.all(
            templates.map((template) => requestResult(store.get(template.id)))
        );
        templates.forEach((template, index) => {
            if (!results[index]) {
                store.add({
                    ...validateProject({ ...template, version: 1 }),
                    updatedAt: new Date().toISOString()
                });
                return;
            }

            const existing = results[index];
            if ((existing.templateRevision ?? 0) < (template.templateRevision ?? 0)) {
                const existingLabels = new Set(
                    existing.objects.map((object) => object.label.trim().toLocaleLowerCase())
                );
                const newObjects = template.objects.filter(
                    (object) => !existingLabels.has(object.label.trim().toLocaleLowerCase())
                );
                const updated = {
                    ...template,
                    ...existing,
                    id: template.id,
                    version: template.version,
                    templateRevision: template.templateRevision,
                    objects: [...existing.objects, ...newObjects]
                };
                store.put({
                    ...validateProject(updated),
                    updatedAt: new Date().toISOString()
                });
            }
        });
        await done;
    }

    async listProjects() {
        const database = await this.open();
        const transaction = database.transaction("projects", "readonly");
        const done = transactionResult(transaction);
        const result = await requestResult(transaction.objectStore("projects").getAll());
        await done;
        return result.sort((first, second) => first.name.localeCompare(second.name));
    }

    async getProject(id) {
        const database = await this.open();
        const transaction = database.transaction("projects", "readonly");
        const done = transactionResult(transaction);
        const result = await requestResult(transaction.objectStore("projects").get(id));
        await done;
        return result;
    }

    async saveProject(project) {
        const database = await this.open();
        const validatedProject = validateProject(project);
        const transaction = database.transaction("projects", "readwrite");
        const done = transactionResult(transaction);
        transaction.objectStore("projects").put({
            ...validatedProject,
            updatedAt: new Date().toISOString()
        });
        await done;
    }

    async deleteProject(id, replacementActiveId) {
        const project = await this.getProject(id);
        if (!project) throw new Error("O projeto selecionado não foi encontrado.");
        if (project.template === true || project.id.startsWith("template-")) {
            throw new Error("Os modelos incluídos no editor não podem ser apagados.");
        }

        const activeProjectId = await this.getActiveProjectId();
        if (activeProjectId === id && !replacementActiveId) {
            throw new Error("Escolha outro projeto antes de apagar o projeto atual.");
        }
        if (activeProjectId === id && !await this.getProject(replacementActiveId)) {
            throw new Error("O projeto que substituirá o atual não foi encontrado.");
        }

        const database = await this.open();
        const transaction = database.transaction(["projects", "metadata"], "readwrite");
        const done = transactionResult(transaction);
        transaction.objectStore("projects").delete(id);
        if (activeProjectId === id) {
            transaction.objectStore("metadata").put({
                key: "activeProjectId",
                value: replacementActiveId
            });
        }
        await done;
    }

    async getActiveProjectId() {
        const database = await this.open();
        const transaction = database.transaction("metadata", "readonly");
        const done = transactionResult(transaction);
        const result = await requestResult(transaction.objectStore("metadata").get("activeProjectId"));
        await done;
        return result?.value;
    }

    async initializeDefaultProject(defaultProjectId, previousDefaultProjectId) {
        const database = await this.open();
        const transaction = database.transaction("metadata", "readwrite");
        const done = transactionResult(transaction);
        const store = transaction.objectStore("metadata");
        const [activeProject, migration] = await Promise.all([
            requestResult(store.get("activeProjectId")),
            requestResult(store.get("initialProjectMigrationVersion"))
        ]);

        if (migration?.value !== 1) {
            if (!activeProject || activeProject.value === previousDefaultProjectId) {
                store.put({ key: "activeProjectId", value: defaultProjectId });
            }
            store.put({ key: "initialProjectMigrationVersion", value: 1 });
        }

        await done;
        return this.getActiveProjectId();
    }

    async setActiveProjectId(id) {
        if (!await this.getProject(id)) {
            throw new Error("O projeto selecionado não foi encontrado.");
        }

        const database = await this.open();
        const transaction = database.transaction("metadata", "readwrite");
        const done = transactionResult(transaction);
        transaction.objectStore("metadata").put({ key: "activeProjectId", value: id });
        await done;
    }
}
