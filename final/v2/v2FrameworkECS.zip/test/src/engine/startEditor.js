import { Initializer } from "../initializer.js";
import { ProjectStore } from "./project/ProjectStore.js";
import { projectTemplates } from "./project/projectTemplates.js";

export async function startEditor({
    canvas,
    scene,
    width = window.innerWidth,
    height = window.innerHeight,
    setupScene
}) {
    if (!canvas) throw new Error("O canvas #game não foi encontrado.");
    if (!scene) throw new Error("A cena Three.js não foi informada.");

    const projectStore = new ProjectStore();
    await projectStore.seedTemplates(projectTemplates);

    const activeProjectId = await projectStore.initializeDefaultProject(
        "template-main",
        "template-test"
    );
    let project = activeProjectId
        ? await projectStore.getProject(activeProjectId)
        : undefined;
    if (!project) {
        project = await projectStore.getProject("template-main");
        if (!project) throw new Error("Não foi possível carregar o projeto inicial Main.");
        await projectStore.setActiveProjectId(project.id);
    }

    const initializer = new Initializer(canvas, width, height, scene, projectStore);
    initializer.StartRenderer();
    initializer.ShadowMapSwitch("on");
    initializer.StateCamera("free");
    initializer.LoadProject(project);
    await initializer.RunCodeSetup(setupScene);
    initializer.DebugTools("on");
    initializer.Modal();
    initializer.initialize();
    initializer.gameLoop();
    return initializer;
}
