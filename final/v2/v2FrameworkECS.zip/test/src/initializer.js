import * as THREE from "three";
import { World } from './ecs/World.js';
import { MovementSystem } from './systems/MovementSystem.js';
import { createPlayer } from './game/PlayerFactory.js';
import { InputSystem } from './systems/InputSystem.js';
import { RenderSystem } from './systems/RenderSystem.js';
import { PlayerControllerSystem } from './systems/PlayerControllerSystem.js';
import { GroundSystem } from './systems/GroundSystem.js';
import { CameraSystem } from './systems/CameraSystem.js';
import { createFirstPersonCamera, createFollowCamera } from './game/CameraFactory.js';
import { GravitySystem } from './systems/GravitySystem.js';
import { AABBCollisionSystem } from './systems/AABBCollisionSystem.js';
import { CapsuleVsAABBCollisionSystem } from './systems/CapsuleVsAABBCollisionSystem.js';
import { createGround, createGroundMaterial } from './game/GroundFactory.js';
import { createWall } from './game/WallFactory.js';
import { LightSystem } from './systems/LightSystem.js';
import { createAmbientLight, createDirectionalLight } from './game/LightFactory.js';
import { ModeSwitchSystem } from './systems/ModeSwitchSystem.js';
import { MouseLookSystem } from './systems/MouseLookSystem.js';
import { OrbitCameraSystem } from './systems/OrbitCameraSystem.js';
import { CameraBasisSystem } from './systems/CameraBasisSystem.js';
import { CameraAimSystem } from './systems/CameraAimSystem.js';
import { GroundSnapSystem } from './systems/GroundSnapSystem.js';
import { StepClimbSystem } from './systems/StepClimbSystem.js';
import { step } from "three/tsl";
import { Transform } from './components/Transform.js';
import { Mesh } from './components/Mesh.js';
import { CapsuleCollider } from './components/CapsuleCollider.js';
import { CapsuleDebugMesh } from './components/CapsuleDebugMesh.js';
import { CameraRig } from './components/CameraRig.js';
import { CameraFollow } from './components/CameraFollow.js';
import { DirectionalLightComponent } from './components/DirectionalLightComponent.js';
import { AmbientLightComponent } from './components/AmbientLightComponent.js';
import { LightHandle } from './components/LightHandle.js';
import { ColliderAABB } from './components/ColliderAABB.js';
import { EditorEngine } from './engine/editor/EditorEngine.js';
import { EditorBridgeSystem } from './engine/editor/EditorBridgeSystem.js';
import { createEditorPrimitive } from './engine/editor/createEditorPrimitive.js';
import { createProjectFromTemplate, defaultProjectSettings, projectTemplates } from './engine/project/projectTemplates.js';
import { exportProjectAsMainJs, importProjectFromMainJs, validateProject } from './engine/project/projectFormat.js';
import { createBeginnerTools } from './engine/beginner.js';

export class Initializer {
  constructor(canvas, width, height, scene, projectStore) {
    this.canvas = canvas;
    this.width = width;
    this.height = height;
    this.scene = scene;
    this.originalSceneBackground = scene.background;
    this.skyboxTexture = undefined;
    this.skyboxLoadRequest = 0;
    this.world = new World();
    this.renderer = undefined;
    this.camera = undefined;
    this.editorCamera = undefined;
    this.cameraEntity = undefined;
    this.selectedGameCamera = undefined;
    this.gameMode = "edit";
    this.gameModeSelect = undefined;
    this.gameModeButton = undefined;
    this.mouseLookSystem = undefined;
    this.orbitCameraSystem = undefined;
    this.cameraBasisSystem = undefined;
    this.cameraAimSystem = undefined;
    this.renderSystem = undefined;
    this.editorEngine = undefined;
    this.simulationSystems = [];
    this.inputSystem = undefined;
    this.player = undefined;
    this.axes = undefined;
    this.grid = undefined;
    this.lastTime = performance.now();
    this.objects = [];
    this.objectGroups = [];
    this.modal = undefined;
    this.modalButton = undefined;
    this.developerCommandsEnabled = false;
    this.projectStore = projectStore;
    this.currentProjectId = undefined;
    this.currentProjectName = "";
    this.projectSettings = { ...defaultProjectSettings };
    this.projectSkyboxSource = null;
    this.pendingObjectSnapshots = [];
    this.settingsModal = undefined;
    this.settingsModalControls = undefined;
    this.projectHubModal = undefined;
    this.projectStatus = undefined;
    this.codeSetupActive = false;
    this.beginner = createBeginnerTools(this);
  }

  StartRenderer() {
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true
    });

    this.renderer.setSize(this.width, this.height);
    this.renderer.setPixelRatio(window.devicePixelRatio);
    this.renderer.setClearColor(0x202030, 1);
  }

  ShadowMapSwitch(state) {
    if(state == "on") {
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFShadowMap;
      this.scene.fog = new THREE.Fog(0x202030, 10, 35);
    } else if(state == "off") {
      //nothing happens
    }
  }

  StateCamera(type, xPos = 0, yPos = 2, zPos = 5, lookAtX = 0, lookAtY = 1, lookAtZ = 0) {
    this.editorCamera = new THREE.PerspectiveCamera(
      this.projectSettings.cameraFov,
      this.width / this.height,
      0.1,
      this.projectSettings.renderDistance
    );

    this.editorCamera.position.set(xPos, yPos, zPos);
    this.editorCamera.lookAt(lookAtX, lookAtY, lookAtZ);
    this.camera = this.editorCamera;

    if (type === "free") {
      this.cameraEntity = undefined;
    } else if (type === "follow" || type === "static") {
      this.cameraEntity = this.AddCamera({
        label: "Câmera",
        type,
        x: xPos,
        y: yPos,
        z: zPos,
        lookAtX,
        lookAtY,
        lookAtZ
      }, true);
    }
  }

  LoadProject(project) {
    const data = validateProject(project);
    this.currentProjectId = data.id;
    this.currentProjectName = data.name;
    this.projectSettings = {
      ...defaultProjectSettings,
      ...data.settings
    };
    this.projectSkyboxSource = data.skyboxSource ?? null;
    this.pendingObjectSnapshots = [];
    this.objectGroups = data.groups.map((group) => ({ ...group }));

    for (const object of data.objects) {
      const values = { ...object.values };
      let record;
      if (object.kind === "player") {
        this.StatePlayer(
          values.shadows ? "on" : "off",
          values.horizontalLength ?? 0.5,
          values.verticalLength ?? 0.5,
          values.wireframePlayer ?? false,
          values.wireframeCapsule ?? false,
          values.transparent ?? true,
          values.opacity ?? 0.5,
          values.x ?? 0,
          values.y ?? 5,
          values.z ?? 0,
          {
            visible: values.capsuleVisible ?? values.wireframeCapsule ?? false,
            transparent: values.capsuleTransparent ?? true,
            opacity: values.capsuleOpacity ?? 0.85,
            color: values.capsuleColor ?? "#ffffff"
          }
        );
        record = this.objects.at(-1);
      } else if (object.kind === "camera") {
        this.AddCamera({ ...values, label: object.label }, object.permanent);
        record = this.objects.at(-1);
      } else if (object.kind === "ground") {
        this.StateGround(
          values.horizontalLength ?? 50,
          values.verticalLength ?? 50,
          object.label,
          object.permanent,
          values
        );
        record = this.objects.at(-1);
      } else if (object.kind === "wall") {
        this.PlaceWall(
          values.x ?? 0,
          values.y ?? 0.5,
          values.z ?? 0,
          values.width ?? 1,
          values.height ?? 1,
          values.depth ?? 1,
          object.label
        );
        record = this.objects.at(-1);
      } else if (object.kind === "stair") {
        this.PlaceStair(
          values.steps ?? 5,
          values.stepHeight ?? 0.25,
          values.stepDepth ?? 0.5,
          values.x ?? 0,
          values.width ?? 3,
          object.label
        );
        record = this.objects.at(-1);
      } else if (object.kind === "light") {
        this.PlaceLight(
          values.x ?? 30,
          values.y ?? 30,
          values.z ?? 30,
          values.intensity ?? 0.35,
          values.resolution ?? this.projectSettings.shadowResolution,
          values.area ?? 32,
          values.bias ?? -0.00001,
          "directional",
          object.label
        );
        record = this.objects.at(-1);
      } else if (object.kind === "ambient") {
        this.PlaceLight(
          0, 0, 0,
          values.intensity ?? 0.35,
          this.projectSettings.shadowResolution,
          32,
          -0.00001,
          "ambient",
          object.label
        );
        record = this.objects.at(-1);
      } else if (object.kind === "geometry") {
        const geometryValues = {
          width: 1,
          height: 1,
          depth: 1,
          radius: 0.5,
          widthSegments: 16,
          heightSegments: 12,
          radiusTop: 0.5,
          radiusBottom: 0.5,
          radialSegments: 12,
          length: 0.8,
          capSegments: 4,
          tube: 0.2,
          tubularSegments: 24,
          p: 2,
          q: 3,
          innerRadius: 0.25,
          outerRadius: 0.65,
          thetaSegments: 24,
          phiSegments: 1,
          startX: -2,
          startY: 0,
          startZ: 0,
          control1X: -1,
          control1Y: 1,
          control1Z: 0,
          control2X: 1,
          control2Y: -1,
          control2Z: 0,
          endX: 2,
          endY: 0,
          endZ: 0,
          rotationX: 0,
          rotationY: 0,
          rotationZ: 0,
          scaleX: 1,
          scaleY: 1,
          scaleZ: 1,
          ...values,
          label: object.label
        };
        record = createEditorPrimitive(this.world, this.scene, geometryValues);
        this.objects.push(record);
      }

      if (record) {
        record.label = object.label;
        record.permanent = Boolean(object.permanent);
        if (object.groupId) record.groupId = object.groupId;
        if (object.source) record.source = object.source;
        record.values = { ...record.values, ...values, label: object.label };
        if (object.meshes) this.pendingObjectSnapshots.push([record, object.meshes]);
      }
    }

    this.ApplyProjectSettings(this.projectSettings);
  }

  async RunCodeSetup(setupScene) {
    if (typeof setupScene !== "function") return;
    const existingObjects = new Set(this.objects);
    this.codeSetupActive = true;
    try {
      await setupScene(this, this.beginner);
    } finally {
      this.codeSetupActive = false;
      for (const object of this.objects) {
        if (!existingObjects.has(object)) object.source = "code";
      }
    }
  }

  FindCodeSetupDuplicate(label) {
    if (!this.codeSetupActive || !label) return undefined;
    const normalizedLabel = label.trim().toLocaleLowerCase();
    return this.objects.find(
      (object) => object.label.trim().toLocaleLowerCase() === normalizedLabel
    );
  }

  ApplyProjectSettings(settings) {
    const updatedSettings = { ...this.projectSettings, ...settings };
    const shadowResolutionChanged =
      this.projectSettings.shadowResolution !== updatedSettings.shadowResolution;
    this.projectSettings = updatedSettings;
    if (this.renderer) {
      this.renderer.shadowMap.enabled = this.projectSettings.shadowsEnabled;
      this.renderer.shadowMap.needsUpdate = true;
    }

    const cameras = [this.editorCamera, ...this.objects
      .filter((object) => object.kind === "camera")
      .map((object) => object.viewCamera)]
      .filter(Boolean);
    for (const camera of cameras) {
      camera.fov = this.projectSettings.cameraFov;
      camera.far = this.projectSettings.renderDistance;
      camera.updateProjectionMatrix();
    }

    for (const object of this.objects) {
      if (object.kind !== "light") continue;
      const data = this.world.getComponent(object.entity, DirectionalLightComponent);
      const handle = this.world.getComponent(object.entity, LightHandle);
      if (!data) continue;
      data.shadowMapSize = this.projectSettings.shadowResolution;
      object.values.resolution = this.projectSettings.shadowResolution;
      if (shadowResolutionChanged && handle?.light.shadow) {
        handle.light.shadow.map?.dispose();
        handle.light.shadow.map = null;
        handle.light.shadow.mapSize.set(
          this.projectSettings.shadowResolution,
          this.projectSettings.shadowResolution
        );
        handle.light.shadow.needsUpdate = true;
      }
    }
  }

  SerializeProject() {
    const project = {
      id: this.currentProjectId,
      version: 1,
      name: this.currentProjectName,
      template: false,
      settings: { ...this.projectSettings },
      skyboxSource: this.projectSkyboxSource,
      groups: this.objectGroups.map((group) => ({ ...group })),
      objects: this.objects.map((object) => ({
        kind: object.kind,
        label: object.label,
        permanent: Boolean(object.permanent),
        ...(object.groupId ? { groupId: object.groupId } : {}),
        ...(object.source ? { source: object.source } : {}),
        values: { ...object.values },
        meshes: this.editorEngine?.serializeObject(object) ?? []
      }))
    };
    return validateProject(project);
  }

  CreateSettingsModal() {
    const overlay = document.createElement("div");
    overlay.className = "debug-settings-overlay";
    overlay.setAttribute("aria-hidden", "true");
    overlay.innerHTML = `
      <section class="debug-settings-dialog" role="dialog" aria-modal="true" aria-labelledby="debug-settings-title">
        <header>
          <div>
            <span class="debug-modal-eyebrow">EDITOR</span>
            <h2 id="debug-settings-title">Configurações da cena</h2>
          </div>
          <button type="button" data-settings-close aria-label="Fechar configurações">&times;</button>
        </header>
        <label class="debug-settings-toggle">
          <span>Sombras globais</span>
          <input type="checkbox" data-setting="shadowsEnabled">
        </label>
        <label>Resolução das sombras <output data-setting-output="shadowResolution"></output>
          <input type="range" min="128" max="4096" step="128" data-setting="shadowResolution">
        </label>
        <label>Distância de renderização <output data-setting-output="renderDistance"></output>
          <input type="range" min="50" max="5000" step="50" data-setting="renderDistance">
        </label>
        <label>Campo de visão da câmera <output data-setting-output="cameraFov"></output>
          <input type="range" min="30" max="120" step="1" data-setting="cameraFov">
        </label>
        <p>As alterações são aplicadas imediatamente. Salve o projeto para guardá-las.</p>
        <section class="debug-project-controls" aria-label="Gerenciamento de projetos">
          <h3>Projetos</h3>
          <label>Projeto salvo
            <select data-project-select></select>
          </label>
          <div class="debug-project-actions">
            <button type="button" data-project-save>Salvar atual</button>
            <button type="button" data-project-open>Abrir selecionado</button>
            <button type="button" class="danger" data-project-delete>Apagar selecionado</button>
            <button type="button" data-project-export>Exportar main.js</button>
            <button type="button" data-project-import-trigger>Importar main.js</button>
          </div>
          <label>Nome do novo projeto
            <input type="text" data-project-name placeholder="Nome do projeto">
          </label>
          <label>Base inicial
            <select data-project-template></select>
          </label>
          <button type="button" class="debug-primary-button" data-project-create>Criar projeto</button>
          <input type="file" accept=".js,text/javascript" data-project-import hidden>
          <output class="debug-project-status" aria-live="polite"></output>
          <p>O main.js exportado guarda dados JSON. A importação não executa código do arquivo.</p>
          <button type="button" class="debug-hub-open" data-open-project-hub>Abrir HUB de projetos</button>
        </section>
        <p>O HUB encontra automaticamente os arquivos src/projects/*Project.js ao iniciar o app.</p>
      </section>
    `;
    document.body.appendChild(overlay);
    this.settingsModal = overlay;
    this.projectStatus = overlay.querySelector(".debug-project-status");
    const projectTemplateSelect = overlay.querySelector("[data-project-template]");
    for (const template of projectTemplates) {
      const option = document.createElement("option");
      option.value = template.id;
      option.textContent = template.name;
      projectTemplateSelect.appendChild(option);
    }

    this.settingsModalControls = {
      shadowsEnabled: overlay.querySelector('[data-setting="shadowsEnabled"]'),
      shadowResolution: overlay.querySelector('[data-setting="shadowResolution"]'),
      renderDistance: overlay.querySelector('[data-setting="renderDistance"]'),
      cameraFov: overlay.querySelector('[data-setting="cameraFov"]')
    };

    overlay.querySelector("[data-settings-close]").addEventListener("click", () => {
      this.CloseSettingsModal();
    });
    overlay.querySelector("[data-open-project-hub]").addEventListener("click", () => {
      this.CloseSettingsModal();
      this.OpenProjectHubModal();
    });
    const projectName = overlay.querySelector("[data-project-name]");
    const projectImport = overlay.querySelector("[data-project-import]");
    overlay.querySelector("[data-project-save]").addEventListener("click", () => {
      this.SaveCurrentProject().catch((error) => this.SetProjectStatus(error.message, true));
    });
    overlay.querySelector("[data-project-open]").addEventListener("click", () => {
      this.OpenSelectedProject().catch((error) => this.SetProjectStatus(error.message, true));
    });
    overlay.querySelector("[data-project-delete]").addEventListener("click", () => {
      this.DeleteSelectedProject().catch((error) => this.SetProjectStatus(error.message, true));
    });
    overlay.querySelector("[data-project-select]").addEventListener("change", () => {
      this.SyncProjectDeleteButton();
    });
    overlay.querySelector("[data-project-export]").addEventListener("click", () => {
      try {
        this.ExportCurrentProject();
      } catch (error) {
        this.SetProjectStatus(error.message, true);
      }
    });
    overlay.querySelector("[data-project-import-trigger]").addEventListener("click", () => {
      projectImport.click();
    });
    projectImport.addEventListener("change", () => {
      const file = projectImport.files?.[0];
      projectImport.value = "";
      this.ImportProjectFile(file).catch((error) => this.SetProjectStatus(error.message, true));
    });
    overlay.querySelector("[data-project-create]").addEventListener("click", () => {
      this.CreateProject(projectTemplateSelect.value, projectName.value)
        .catch((error) => this.SetProjectStatus(error.message, true));
    });
    this.RefreshProjectOptions()
      .catch((error) => this.SetProjectStatus(error.message, true));
    overlay.addEventListener("pointerdown", (event) => {
      if (event.target === overlay) this.CloseSettingsModal();
    });
    overlay.addEventListener("input", (event) => {
      const input = event.target.closest("[data-setting]");
      if (!input) return;

      const setting = input.dataset.setting;
      const value = input.type === "checkbox" ? input.checked : Number(input.value);
      this.ApplyProjectSettings({ [setting]: value });
      this.SyncSettingsModal();
    });
    this.SyncSettingsModal();
  }

  SyncSettingsModal() {
    if (!this.settingsModalControls) return;
    for (const [setting, input] of Object.entries(this.settingsModalControls)) {
      if (input.type === "checkbox") {
        input.checked = this.projectSettings[setting];
      } else {
        input.value = String(this.projectSettings[setting]);
        this.settingsModal.querySelector(`[data-setting-output="${setting}"]`).value =
          String(this.projectSettings[setting]);
      }
    }
  }

  OpenSettingsModal() {
    if (!this.settingsModal) this.CreateSettingsModal();
    this.SyncSettingsModal();
    this.settingsModal.classList.add("open");
    this.settingsModal.setAttribute("aria-hidden", "false");
  }

  CloseSettingsModal() {
    if (!this.settingsModal) return;
    this.settingsModal.classList.remove("open");
    this.settingsModal.setAttribute("aria-hidden", "true");
  }

  CreateProjectHubModal() {
    const overlay = document.createElement("div");
    overlay.className = "debug-project-hub-overlay";
    overlay.setAttribute("aria-hidden", "true");
    overlay.innerHTML = `
      <section class="debug-project-hub-dialog" role="dialog" aria-modal="true" aria-labelledby="debug-project-hub-title">
        <header>
          <div>
            <span class="debug-modal-eyebrow">PROJECT LIBRARY</span>
            <h2 id="debug-project-hub-title">HUB de projetos</h2>
          </div>
          <button type="button" data-hub-close aria-label="Fechar HUB">&times;</button>
        </header>
        <label>Nome da cópia
          <input type="text" data-hub-project-name placeholder="Nome do projeto">
        </label>
        <section class="debug-project-hub-section">
          <h3>Modelos do HUB</h3>
          <div class="debug-project-hub-list" data-hub-template-list></div>
        </section>
        <section class="debug-project-hub-section">
          <h3>Projetos deste navegador</h3>
          <div class="debug-project-hub-list" data-hub-local-list></div>
        </section>
        <output class="debug-project-hub-status" aria-live="polite"></output>
      </section>
    `;
    document.body.appendChild(overlay);
    this.projectHubModal = overlay;

    overlay.querySelector("[data-hub-close]").addEventListener("click", () => {
      this.CloseProjectHubModal();
    });
    overlay.addEventListener("pointerdown", (event) => {
      if (event.target === overlay) this.CloseProjectHubModal();
    });
  }

  OpenProjectHubModal() {
    if (!this.projectHubModal) this.CreateProjectHubModal();
    this.projectHubModal.classList.add("open");
    this.projectHubModal.setAttribute("aria-hidden", "false");
    this.RefreshProjectHub()
      .catch((error) => {
        this.projectHubModal.querySelector(".debug-project-hub-status").textContent = error.message;
      });
  }

  async RefreshProjectHub() {
    if (!this.projectHubModal || !this.projectStore) {
      throw new Error("O HUB de projetos não está disponível.");
    }

    const templateList = this.projectHubModal.querySelector("[data-hub-template-list]");
    const localList = this.projectHubModal.querySelector("[data-hub-local-list]");
    const status = this.projectHubModal.querySelector(".debug-project-hub-status");
    const nameInput = this.projectHubModal.querySelector("[data-hub-project-name]");
    templateList.replaceChildren();
    localList.replaceChildren();
    status.textContent = "Carregando projetos...";

    const addCard = (project, isLocal) => {
      const card = document.createElement("article");
      card.className = "debug-project-hub-card";
      const heading = document.createElement("h3");
      heading.textContent = project.name;
      const description = document.createElement("p");
      description.textContent = isLocal
        ? (project.id === this.currentProjectId
          ? "Projeto atual, com alterações em andamento."
          : "Projeto salvo neste navegador.")
        : project.description ?? "";
      const file = document.createElement("code");
      file.textContent = isLocal
        ? "Armazenado neste navegador"
        : project.hubPath.replace("./", "src/projects/");
      const openButton = document.createElement("button");
      openButton.type = "button";
      const isCurrentProject = isLocal && project.id === this.currentProjectId;
      openButton.textContent = isCurrentProject
        ? "Em edição"
        : isLocal ? "Abrir projeto" : "Criar cópia e abrir";
      openButton.disabled = isCurrentProject;
      openButton.addEventListener("click", () => {
        if (isLocal) {
          this.OpenSavedProject(project.id).catch((error) => {
            status.textContent = error.message;
          });
          return;
        }

        const projectName = nameInput.value.trim() || `${project.name} (cópia)`;
        this.OpenHubProject(project, projectName).catch((error) => {
          status.textContent = error.message;
        });
      });
      card.append(heading, description, file, openButton);
      (isLocal ? localList : templateList).appendChild(card);
    };

    for (const project of projectTemplates) addCard(project, false);

    const currentProject = this.SerializeProject();
    const savedProjects = (await this.projectStore.listProjects())
      .filter((project) => !project.template);
    const localProjectsById = new Map(savedProjects.map((project) => [project.id, project]));
    localProjectsById.set(currentProject.id, currentProject);
    const localProjects = [...localProjectsById.values()];
    for (const project of localProjects) addCard(project, true);

    status.textContent = localProjects.length
      ? ""
      : "Nenhum projeto local salvo ainda.";
  }

  CloseProjectHubModal() {
    if (!this.projectHubModal) return;
    this.projectHubModal.classList.remove("open");
    this.projectHubModal.setAttribute("aria-hidden", "true");
  }

  async OpenHubProject(template, name) {
    if (!this.projectStore) throw new Error("O armazenamento de projetos não está disponível.");
    if (!name.trim()) throw new Error("Informe um nome para a cópia do projeto.");

    await this.SaveCurrentProject();
    const project = createProjectFromTemplate(template.id, name);
    await this.projectStore.saveProject(project);
    await this.projectStore.setActiveProjectId(project.id);
    window.location.reload();
  }

  async OpenSavedProject(projectId) {
    if (!this.projectStore) throw new Error("O armazenamento de projetos não está disponível.");
    await this.SaveCurrentProject();
    await this.projectStore.setActiveProjectId(projectId);
    window.location.reload();
  }

  SetProjectStatus(message, isError = false) {
    if (!this.projectStatus) return;
    this.projectStatus.textContent = message;
    this.projectStatus.dataset.error = String(isError);
  }

  async RefreshProjectOptions() {
    const select = this.settingsModal?.querySelector("[data-project-select]");
    if (!select || !this.projectStore) return;

    const projects = await this.projectStore.listProjects();
    select.replaceChildren();
    for (const project of projects) {
      const option = document.createElement("option");
      option.value = project.id;
      option.textContent = project.name;
      option.dataset.deletable = String(!this.IsBundledProject(project));
      select.appendChild(option);
    }
    select.value = this.currentProjectId;
    this.SyncProjectDeleteButton();
  }

  IsBundledProject(project) {
    return project.template === true || project.id.startsWith("template-");
  }

  SyncProjectDeleteButton() {
    const select = this.settingsModal?.querySelector("[data-project-select]");
    const deleteButton = this.settingsModal?.querySelector("[data-project-delete]");
    if (!select || !deleteButton) return;
    const selectedOption = select.selectedOptions[0];
    deleteButton.disabled = selectedOption?.dataset.deletable !== "true";
    deleteButton.title = deleteButton.disabled
      ? "Os modelos incluídos no editor não podem ser apagados."
      : "Apagar o projeto selecionado";
  }

  async DeleteSelectedProject() {
    const projectId = this.settingsModal?.querySelector("[data-project-select]")?.value;
    if (!projectId || !this.projectStore) {
      throw new Error("Selecione um projeto para apagar.");
    }

    const project = await this.projectStore.getProject(projectId);
    if (!project) throw new Error("O projeto selecionado não foi encontrado.");
    if (this.IsBundledProject(project)) {
      throw new Error("Os modelos incluídos no editor não podem ser apagados.");
    }

    const isCurrentProject = project.id === this.currentProjectId;
    const confirmation = isCurrentProject
      ? `Apagar "${project.name}"? O projeto atual e suas alterações não salvas serão perdidos. O editor abrirá o projeto Main.`
      : `Apagar "${project.name}"? Esta ação não pode ser desfeita.`;
    if (!window.confirm(confirmation)) return;

    await this.projectStore.deleteProject(
      projectId,
      isCurrentProject ? "template-main" : undefined
    );
    if (isCurrentProject) {
      window.location.reload();
      return;
    }

    this.SetProjectStatus(`Projeto "${project.name}" apagado.`);
    await this.RefreshProjectOptions();
    if (this.projectHubModal?.classList.contains("open")) {
      await this.RefreshProjectHub();
    }
  }

  async SaveCurrentProject() {
    if (!this.projectStore) throw new Error("O armazenamento de projetos não está disponível.");
    await this.projectStore.saveProject(this.SerializeProject());
    this.SetProjectStatus(`Projeto "${this.currentProjectName}" salvo localmente.`);
    await this.RefreshProjectOptions();
  }

  async CreateProject(templateId, name) {
    if (!this.projectStore) throw new Error("O armazenamento de projetos não está disponível.");
    if (!name.trim()) throw new Error("Informe um nome para o novo projeto.");

    await this.SaveCurrentProject();
    const project = createProjectFromTemplate(templateId, name);
    await this.projectStore.saveProject(project);
    await this.projectStore.setActiveProjectId(project.id);
    window.location.reload();
  }

  async OpenSelectedProject() {
    const projectId = this.settingsModal?.querySelector("[data-project-select]")?.value;
    if (!projectId) throw new Error("Selecione um projeto para abrir.");
    if (projectId === this.currentProjectId) {
      this.SetProjectStatus("Este projeto já está aberto.");
      return;
    }

    await this.SaveCurrentProject();
    await this.projectStore.setActiveProjectId(projectId);
    window.location.reload();
  }

  ExportCurrentProject() {
    const source = exportProjectAsMainJs(this.SerializeProject());
    const url = URL.createObjectURL(new Blob([source], { type: "text/javascript" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = "main.js";
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 0);
    this.SetProjectStatus("Projeto exportado como main.js.");
  }

  async ImportProjectFile(file) {
    if (!file) return;
    const source = await file.text();
    const importedProject = importProjectFromMainJs(source);
    await this.SaveCurrentProject();
    const project = {
      ...importedProject,
      id: crypto.randomUUID(),
      template: false
    };
    await this.projectStore.saveProject(project);
    await this.projectStore.setActiveProjectId(project.id);
    window.location.reload();
  }

  StatePlayer(ShadowsState, HorizontalLenght, VerticalLenght, WireframeForPlayer = false, WireframeForCapsule = false, TransparencyForPlayer = true, OpacityForPlayer = 0.5, xPos = 0, yPos = 5, zPos = 0, capsuleSettings = {}) {
    const existingPlayer = this.FindCodeSetupDuplicate("Player");
    if (existingPlayer) return;

    if(ShadowsState == "on") {
      ShadowsState = true;
    } else if (ShadowsState == "off") {
      ShadowsState = false;
    }
    const capsuleVisible = capsuleSettings.visible ?? WireframeForCapsule;
    const capsuleTransparent = capsuleSettings.transparent ?? true;
    const capsuleOpacity = capsuleSettings.opacity ?? 0.85;
    const capsuleColor = capsuleSettings.color ?? "#ffffff";
    this.player = createPlayer(
      this.world,
      this.scene,
      ShadowsState,
      HorizontalLenght,
      VerticalLenght,
      WireframeForPlayer,
      WireframeForCapsule,
      TransparencyForPlayer,
      OpacityForPlayer,
      xPos,
      yPos,
      zPos,
      {
        visible: capsuleVisible,
        transparent: capsuleTransparent,
        opacity: capsuleOpacity,
        color: capsuleColor
      }
    );
    this.objects.push({
      kind: "player",
      label: "Player",
      entity: this.player,
      permanent: true,
      values: {
        shadows: ShadowsState,
        horizontalLength: HorizontalLenght,
        verticalLength: VerticalLenght,
        wireframePlayer: WireframeForPlayer,
        wireframeCapsule: WireframeForCapsule,
        capsuleVisible,
        capsuleTransparent,
        capsuleOpacity,
        capsuleColor,
        transparent: TransparencyForPlayer,
        opacity: OpacityForPlayer,
        x: xPos,
        y: yPos,
        z: zPos
      }
    });
  }

  Modal() {
    if (this.modal) return;

    const button = document.createElement("button");
    button.type = "button";
    button.className = "debug-modal-button";
    button.setAttribute("aria-label", "Abrir menu de debug");
    button.innerHTML = `
      <span class="debug-modal-button-icon" aria-hidden="true">
        <span></span><span></span><span></span>
      </span>
    `;
    document.body.appendChild(button);
    this.modalButton = button;

    const overlay = document.createElement("div");
    overlay.className = "debug-modal-overlay";
    overlay.setAttribute("aria-hidden", "true");

    overlay.innerHTML = `
      <div class="debug-modal" role="dialog" aria-modal="true" aria-label="Debug menu">
        <div class="debug-modal-header">
          <div>
            <span class="debug-modal-eyebrow">SCENE DEBUG</span>
            <h2>Objetos da cena</h2>
          </div>
          <button class="debug-settings-open" type="button" aria-label="Configurações" title="Configurações">⚙</button>
          <button class="debug-modal-close" type="button" aria-label="Fechar">&times;</button>
        </div>
        <div class="debug-modal-content">
          <div class="game-mode-controls">
            <select aria-label="Visualizar câmera no modo de edição"></select>
            <button type="button" class="game-mode-button">JOGAR</button>
          </div>
          <section class="debug-skybox-controls" aria-label="Skybox da cena">
            <h3>Skybox</h3>
            <p>Use uma imagem panorâmica equiretangular (proporção 2:1).</p>
            <label>Imagem por arquivo
              <input type="file" accept="image/*" data-skybox-file>
            </label>
            <label>URL da imagem
              <input type="url" placeholder="https://..." data-skybox-url>
            </label>
            <div class="editor-texture-actions">
              <button type="button" data-skybox-apply>Aplicar skybox</button>
              <button type="button" data-skybox-remove disabled>Remover skybox</button>
            </div>
            <output class="debug-skybox-status" aria-live="polite"></output>
          </section>
          <div class="editor-selection-tools" hidden>
            <strong class="editor-selection-name"></strong>
            <div class="editor-transform-modes">
              <button type="button" data-transform-mode="translate" aria-label="Mover (M)">Mover <kbd>M</kbd></button>
              <button type="button" data-transform-mode="rotate" aria-label="Rotacionar (R)">Rotacionar <kbd>R</kbd></button>
              <button type="button" data-transform-mode="scale" aria-label="Escalar (E)">Escalar <kbd>E</kbd></button>
            </div>
          </div>
          <section class="editor-material-editor" hidden aria-label="Material do objeto selecionado">
            <h3>Material</h3>
            <label>Tipo
              <select data-material-type>
                <option value="standard">Standard</option>
                <option value="phong">Phong</option>
                <option value="lambert">Lambert</option>
                <option value="basic">Basic (sem iluminação)</option>
              </select>
            </label>
            <div class="editor-material-grid">
              <label>Cor
                <input type="color" data-material-property="color">
              </label>
              <label data-material-types="standard">Metalness
                <input type="range" min="0" max="1" step="0.01" data-material-property="metalness">
                <output data-material-output="metalness"></output>
              </label>
              <label data-material-types="standard">Roughness
                <input type="range" min="0" max="1" step="0.01" data-material-property="roughness">
                <output data-material-output="roughness"></output>
              </label>
              <label data-material-types="phong">Shininess
                <input type="range" min="0" max="200" step="1" data-material-property="shininess">
                <output data-material-output="shininess"></output>
              </label>
              <label data-material-types="standard phong lambert">Emissive
                <input type="color" data-material-property="emissive">
              </label>
              <label data-material-types="standard phong lambert">Emissive intensity
                <input type="range" min="0" max="5" step="0.05" data-material-property="emissiveIntensity">
                <output data-material-output="emissiveIntensity"></output>
              </label>
              <label>Opacity
                <input type="range" min="0" max="1" step="0.01" data-material-property="opacity">
                <output data-material-output="opacity"></output>
              </label>
              <label>Faces
                <select data-material-property="side">
                  <option value="front">Front</option>
                  <option value="double">Double</option>
                  <option value="back">Back</option>
                </select>
              </label>
            </div>
            <div class="editor-material-toggles">
              <label><input type="checkbox" data-material-property="transparent"> Transparente</label>
              <label><input type="checkbox" data-material-property="wireframe"> Wireframe</label>
              <label><input type="checkbox" data-material-property="castShadow"> Emitir sombras</label>
            </div>
            <div class="editor-texture-controls">
              <label>Textura por arquivo
                <input type="file" accept="image/*" data-texture-file>
              </label>
              <label>URL da imagem
                <input type="url" placeholder="https://..." data-texture-url>
              </label>
              <div class="editor-texture-actions">
                <button type="button" data-texture-apply>Aplicar URL</button>
                <button type="button" data-texture-remove disabled>Remover textura</button>
              </div>
              <output class="editor-material-status" aria-live="polite"></output>
            </div>
          </section>
          <div class="debug-developer-settings">
            <label for="debug-developer-controls">Comandos de desenvolvedor (G/H)</label>
            <select id="debug-developer-controls">
              <option value="disabled" selected>Desativados</option>
              <option value="enabled">Ativados</option>
            </select>
          </div>
          <form class="debug-object-form" hidden>
            <label>
              Tipo
              <select name="kind">
                <option value="wall">Parede</option>
                <option value="light">Luz direcional</option>
                <option value="ambient" disabled>Luz ambiente</option>
                <option value="ground">Chão</option>
                <option value="stair">Escada</option>
                <option value="geometry">Forma geométrica</option>
                <option value="player" disabled>Player</option>
                <option value="camera">Câmera de jogo</option>
              </select>
            </label>
            <div class="debug-form-fields"></div>
            <div class="debug-form-actions">
              <button class="debug-form-cancel" type="button" data-form-cancel>Cancelar</button>
              <button class="debug-primary-button" type="submit">Criar objeto</button>
            </div>
          </form>
          <div class="debug-object-list">
            <div class="debug-list-heading">
              <span>Objetos existentes</span>
              <div class="debug-list-heading-actions">
                <span class="debug-object-count">0</span>
                <button class="debug-group-create-button" type="button">Criar conjunto</button>
                <button class="debug-create-button" type="button">Criar novo objeto</button>
              </div>
            </div>
            <div class="debug-list-items"></div>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);
    this.modal = overlay;
    this.CreateSettingsModal();
    overlay.querySelector(".debug-settings-open").addEventListener("click", () => {
      this.OpenSettingsModal();
    });

    this.gameModeSelect = overlay.querySelector(".game-mode-controls select");
    this.gameModeButton = overlay.querySelector(".game-mode-button");
    this.gameModeSelect.addEventListener("change", () => {
      this.SelectEditorCamera(this.gameModeSelect.value);
    });
    this.gameModeButton.addEventListener("click", () => {
      this.SetGameMode(this.gameMode === "play" ? "edit" : "play");
    });
    this.RefreshCameraOptions();

    const closeButton = overlay.querySelector(".debug-modal-close");
    const form = overlay.querySelector(".debug-object-form");
    const kindSelect = form.elements.kind;
    const fields = overlay.querySelector(".debug-form-fields");
    const submitButton = form.querySelector("button[type='submit']");
    const cancelFormButton = form.querySelector("[data-form-cancel]");
    const createButton = overlay.querySelector(".debug-create-button");
    const createGroupButton = overlay.querySelector(".debug-group-create-button");
    const developerControlsSelect = overlay.querySelector("#debug-developer-controls");
    const skyboxFile = overlay.querySelector("[data-skybox-file]");
    const skyboxUrl = overlay.querySelector("[data-skybox-url]");
    const skyboxApply = overlay.querySelector("[data-skybox-apply]");
    const skyboxRemove = overlay.querySelector("[data-skybox-remove]");
    const skyboxStatus = overlay.querySelector(".debug-skybox-status");
    let editingObject = null;
    let draggedObject = null;

    const field = (name, label, value, type = "number", step = "0.1", minimum) =>
      `<label>${label}<input name="${name}" type="${type}" step="${step}"${minimum === undefined ? "" : ` min="${minimum}"`} value="${value}" required></label>`;

    const updateGeometryFieldVisibility = () => {
      const geometryType = fields.querySelector("[name='geometryType']")?.value;
      const positiveFields = new Set([
        "width", "height", "depth", "radius", "radiusTop", "radiusBottom",
        "length", "tube", "innerRadius", "outerRadius"
      ]);
      const segmentFields = new Set([
        "widthSegments", "heightSegments", "radialSegments", "tubularSegments",
        "capSegments", "thetaSegments", "phiSegments", "p", "q"
      ]);
      for (const group of fields.querySelectorAll("[data-geometry-fields]")) {
        const visible = group.dataset.geometryFields === geometryType;
        group.hidden = !visible;
        for (const input of group.querySelectorAll("input")) {
          input.disabled = !visible;
          if (positiveFields.has(input.name)) {
            input.min = "0.01";
            input.step = "any";
          }
          if (segmentFields.has(input.name)) {
            input.min = input.name === "heightSegments" || input.name === "capSegments"
              || input.name === "phiSegments" || input.name === "p" || input.name === "q"
              ? "1" : "3";
            input.max = "128";
          }
        }
      }
    };

    const renderFields = () => {
      const labelValue = String(editingObject?.label ?? "").replaceAll('"', "&quot;");
      const labelField = `<label>Nome do objeto<input name="label" type="text" value="${labelValue}" required></label>`;
      if (kindSelect.value === "wall") {
        fields.innerHTML = `
          ${labelField}
          ${field("x", "Posição X", editingObject?.values.x ?? 0)}
          ${field("y", "Posição Y", editingObject?.values.y ?? 0.5)}
          ${field("z", "Posição Z", editingObject?.values.z ?? -5)}
          ${field("width", "Largura", editingObject?.values.width ?? 6)}
          ${field("height", "Altura", editingObject?.values.height ?? 1)}
          ${field("depth", "Profundidade", editingObject?.values.depth ?? 1)}
        `;
      } else if (kindSelect.value === "light") {
        fields.innerHTML = `
          ${labelField}
          ${field("x", "Posição X", editingObject?.values.x ?? 30)}
          ${field("y", "Posição Y", editingObject?.values.y ?? 30)}
          ${field("z", "Posição Z", editingObject?.values.z ?? 30)}
          ${field("intensity", "Intensidade", editingObject?.values.intensity ?? 0.35)}
          ${field("resolution", "Resolução", editingObject?.values.resolution ?? 2048, "number", "256")}
          ${field("area", "Área da sombra", editingObject?.values.area ?? 32)}
          ${field("bias", "Bias da sombra", editingObject?.values.bias ?? -0.00001, "number", "0.00001")}
        `;
      } else if (kindSelect.value === "ambient") {
        fields.innerHTML = `
          ${labelField}
          ${field("intensity", "Intensidade", editingObject?.values.intensity ?? 0.35)}
        `;
      } else if (kindSelect.value === "ground") {
        const values = editingObject?.values ?? {};
        fields.innerHTML = `
          ${labelField}
          ${field("horizontalLength", "Comprimento", values.horizontalLength ?? 50)}
          ${field("verticalLength", "Largura", values.verticalLength ?? 50)}
          <label>Tipo de material
            <select name="materialType">
              <option value="standard" ${(values.materialType ?? "standard") === "standard" ? "selected" : ""}>Standard</option>
              <option value="phong" ${values.materialType === "phong" ? "selected" : ""}>Phong</option>
              <option value="lambert" ${values.materialType === "lambert" ? "selected" : ""}>Lambert</option>
              <option value="basic" ${values.materialType === "basic" ? "selected" : ""}>Basic</option>
            </select>
          </label>
          <label>Cor do chão
            <input name="color" type="color" value="${values.color ?? "#ffffff"}">
          </label>
          <label class="debug-range-label">Metalness
            <input name="metalness" type="range" min="0" max="1" step="0.01" value="${values.metalness ?? 0}">
          </label>
          <label class="debug-range-label">Roughness
            <input name="roughness" type="range" min="0" max="1" step="0.01" value="${values.roughness ?? 1}">
          </label>
          <label class="debug-range-label">Brilho Phong
            <input name="shininess" type="range" min="0" max="200" step="1" value="${values.shininess ?? 30}">
          </label>
          <label>Lados visíveis
            <select name="side">
              <option value="front" ${(values.side ?? "front") === "front" ? "selected" : ""}>Frente</option>
              <option value="double" ${values.side === "double" ? "selected" : ""}>Double (dois lados)</option>
              <option value="back" ${values.side === "back" ? "selected" : ""}>Verso</option>
            </select>
          </label>
          <label class="debug-checkbox-label"><input name="transparent" type="checkbox" ${values.transparent ? "checked" : ""}> Transparência</label>
          <label class="debug-range-label">Opacidade
            <input name="opacity" type="range" min="0" max="1" step="0.01" value="${values.opacity ?? 1}">
          </label>
          <label class="debug-checkbox-label"><input name="wireframe" type="checkbox" ${values.wireframe ? "checked" : ""}> Wireframe</label>
          <label class="debug-checkbox-label"><input name="receiveShadow" type="checkbox" ${values.receiveShadow !== false ? "checked" : ""}> Receber sombras</label>
        `;
      } else if (kindSelect.value === "player") {
        fields.innerHTML = `
          ${labelField}
          ${field("radius", "Raio", editingObject?.values.horizontalLength ?? 0.5, "number", "any", "0.01")}
          ${field("halfHeight", "Meia altura", editingObject?.values.verticalLength ?? 0.5, "number", "any", "0.01")}
          ${field("x", "Posição X", editingObject?.values.x ?? 0)}
          ${field("y", "Posição Y", editingObject?.values.y ?? 5)}
          ${field("z", "Posição Z", editingObject?.values.z ?? 0)}
          <label class="debug-checkbox-label"><input name="shadows" type="checkbox" ${editingObject?.values.shadows ? "checked" : ""}> Projetar sombras</label>
          <label class="debug-checkbox-label"><input name="wireframePlayer" type="checkbox" ${editingObject?.values.wireframePlayer ? "checked" : ""}> Wireframe do player</label>
          <h4 class="debug-form-subheading">Cápsula de colisão</h4>
          <label class="debug-checkbox-label"><input name="capsuleVisible" type="checkbox" ${(editingObject?.values.capsuleVisible ?? editingObject?.values.wireframeCapsule) ? "checked" : ""}> Exibir cápsula</label>
          <label class="debug-checkbox-label"><input name="wireframeCapsule" type="checkbox" ${editingObject?.values.wireframeCapsule ? "checked" : ""}> Wireframe da cápsula</label>
          <label class="debug-checkbox-label"><input name="capsuleTransparent" type="checkbox" ${editingObject?.values.capsuleTransparent !== false ? "checked" : ""}> Transparência da cápsula</label>
          <label>Cor da cápsula
            <input name="capsuleColor" type="color" value="${editingObject?.values.capsuleColor ?? "#ffffff"}">
          </label>
          <label class="debug-range-label">Opacidade da cápsula
            <input name="capsuleOpacity" type="range" min="0" max="1" step="0.01" value="${editingObject?.values.capsuleOpacity ?? 0.85}">
          </label>
          <label class="debug-checkbox-label"><input name="transparent" type="checkbox" ${editingObject?.values.transparent ? "checked" : ""}> Transparência</label>
          <label class="debug-range-label">Opacidade do player
            <input name="opacity" type="range" min="0" max="1" step="0.01" value="${editingObject?.values.opacity ?? 1}">
          </label>
        `;
      } else if (kindSelect.value === "camera") {
        const cameraMode = editingObject?.values.type ?? "follow";
        fields.innerHTML = `
          ${labelField}
          <label>Modo da câmera
            <select name="cameraMode">
              <option value="follow" ${cameraMode === "follow" ? "selected" : ""}>Follow (acompanha)</option>
              <option value="firstPerson" ${cameraMode === "firstPerson" ? "selected" : ""}>Primeira pessoa</option>
              <option value="birdseye" ${cameraMode === "birdseye" ? "selected" : ""}>Bird's eye (vista do céu)</option>
              <option value="static" ${cameraMode === "static" ? "selected" : ""}>Estática</option>
            </select>
          </label>
          ${field("x", "Posição / deslocamento X", editingObject?.values.x ?? 0)}
          ${field("y", "Altura / posição Y", editingObject?.values.y ?? (cameraMode === "birdseye" ? 40 : cameraMode === "firstPerson" ? 1.6 : 2))}
          ${field("z", "Posição / deslocamento Z", editingObject?.values.z ?? (cameraMode === "firstPerson" || cameraMode === "birdseye" ? 0 : 5))}
          ${field("lookAtX", cameraMode === "firstPerson" ? "Direção relativa X" : "Olhar para X", editingObject?.values.lookAtX ?? 0)}
          ${field("lookAtY", cameraMode === "firstPerson" ? "Direção relativa Y" : "Olhar para Y", editingObject?.values.lookAtY ?? (cameraMode === "birdseye" ? 0 : cameraMode === "firstPerson" ? 0 : 1))}
          ${field("lookAtZ", cameraMode === "firstPerson" ? "Direção relativa Z" : "Olhar para Z", editingObject?.values.lookAtZ ?? (cameraMode === "firstPerson" ? -1 : 0))}
        `;
        fields.querySelector("[name='cameraMode']").addEventListener("change", (event) => {
          const mode = event.currentTarget.value;
          for (const [axis, name] of [
            ["X", "lookAtX"],
            ["Y", "lookAtY"],
            ["Z", "lookAtZ"]
          ]) {
            const label = fields.querySelector(`[name='${name}']`).parentElement;
            label.firstChild.textContent =
              `${mode === "firstPerson" ? "Direção relativa" : "Olhar para"} ${axis}`;
          }
          fields.querySelector("[name='y']").value =
            mode === "birdseye" ? 40 : mode === "firstPerson" ? 1.6 : 2;
          fields.querySelector("[name='z']").value =
            mode === "firstPerson" || mode === "birdseye" ? 0 : 5;
          fields.querySelector("[name='lookAtX']").value = 0;
          fields.querySelector("[name='lookAtY']").value =
            mode === "birdseye" || mode === "firstPerson" ? 0 : 1;
          fields.querySelector("[name='lookAtZ']").value =
            mode === "firstPerson" ? -1 : 0;
        });
      } else if (kindSelect.value === "geometry") {
        const selectedGeometry = editingObject?.values.geometryType ?? "box";
        const value = (name, fallback) => editingObject?.values[name] ?? fallback;
        fields.innerHTML = `
          ${labelField}
          <label>Forma
            <select name="geometryType">
              <option value="box" ${selectedGeometry === "box" ? "selected" : ""}>Caixa</option>
              <option value="sphere" ${selectedGeometry === "sphere" ? "selected" : ""}>Esfera</option>
              <option value="cylinder" ${selectedGeometry === "cylinder" ? "selected" : ""}>Cilindro</option>
              <option value="cone" ${selectedGeometry === "cone" ? "selected" : ""}>Cone</option>
              <option value="capsule" ${selectedGeometry === "capsule" ? "selected" : ""}>Cápsula</option>
              <option value="torus" ${selectedGeometry === "torus" ? "selected" : ""}>Torus (anel)</option>
              <option value="torusKnot" ${selectedGeometry === "torusKnot" ? "selected" : ""}>Torus Knot</option>
              <option value="ring" ${selectedGeometry === "ring" ? "selected" : ""}>Anel plano</option>
              <option value="tube" ${selectedGeometry === "tube" ? "selected" : ""}>Tubo curvo</option>
            </select>
          </label>
          ${field("x", "Posição X", value("x", 0))}
          ${field("y", "Posição Y", value("y", 1))}
          ${field("z", "Posição Z", value("z", 0))}
          <div class="debug-geometry-fields" data-geometry-fields="box">
            ${field("width", "Largura", value("width", 1))}
            ${field("height", "Altura", value("height", 1))}
            ${field("depth", "Profundidade", value("depth", 1))}
          </div>
          <div class="debug-geometry-fields" data-geometry-fields="sphere">
            ${field("radius", "Raio", value("radius", 0.5))}
            ${field("widthSegments", "Segmentos horizontais", value("widthSegments", 16), "number", "1")}
            ${field("heightSegments", "Segmentos verticais", value("heightSegments", 12), "number", "1")}
          </div>
          <div class="debug-geometry-fields" data-geometry-fields="cylinder">
            ${field("radiusTop", "Raio superior", value("radiusTop", 0.5))}
            ${field("radiusBottom", "Raio inferior", value("radiusBottom", 0.5))}
            ${field("height", "Altura", value("height", 1))}
            ${field("radialSegments", "Segmentos radiais", value("radialSegments", 12), "number", "1")}
          </div>
          <div class="debug-geometry-fields" data-geometry-fields="cone">
            ${field("radius", "Raio", value("radius", 0.5))}
            ${field("height", "Altura", value("height", 1))}
            ${field("radialSegments", "Segmentos radiais", value("radialSegments", 12), "number", "1")}
          </div>
          <div class="debug-geometry-fields" data-geometry-fields="capsule">
            ${field("radius", "Raio", value("radius", 0.35))}
            ${field("length", "Comprimento central", value("length", 0.8))}
            ${field("capSegments", "Segmentos das pontas", value("capSegments", 4), "number", "1")}
            ${field("radialSegments", "Segmentos radiais", value("radialSegments", 8), "number", "1")}
          </div>
          <div class="debug-geometry-fields" data-geometry-fields="torus">
            ${field("radius", "Raio central", value("radius", 0.65))}
            ${field("tube", "Espessura", value("tube", 0.2))}
            ${field("radialSegments", "Segmentos radiais", value("radialSegments", 8), "number", "1")}
            ${field("tubularSegments", "Segmentos do anel", value("tubularSegments", 24), "number", "1")}
          </div>
          <div class="debug-geometry-fields" data-geometry-fields="torusKnot">
            ${field("radius", "Raio central", value("radius", 0.65))}
            ${field("tube", "Espessura", value("tube", 0.18))}
            ${field("tubularSegments", "Segmentos do tubo", value("tubularSegments", 48), "number", "1")}
            ${field("radialSegments", "Segmentos radiais", value("radialSegments", 6), "number", "1")}
            ${field("p", "Voltas P", value("p", 2), "number", "1")}
            ${field("q", "Voltas Q", value("q", 3), "number", "1")}
          </div>
          <div class="debug-geometry-fields" data-geometry-fields="ring">
            ${field("innerRadius", "Raio interno", value("innerRadius", 0.25))}
            ${field("outerRadius", "Raio externo", value("outerRadius", 0.65))}
            ${field("thetaSegments", "Segmentos do círculo", value("thetaSegments", 24), "number", "1")}
            ${field("phiSegments", "Segmentos da seção", value("phiSegments", 1), "number", "1")}
          </div>
          <div class="debug-geometry-fields" data-geometry-fields="tube">
            ${field("radius", "Raio do tubo", value("radius", 0.15))}
            ${field("tubularSegments", "Segmentos do caminho", value("tubularSegments", 32), "number", "1")}
            ${field("radialSegments", "Segmentos radiais", value("radialSegments", 8), "number", "1")}
            ${field("startX", "Início X", value("startX", -2))}
            ${field("startY", "Início Y", value("startY", 0))}
            ${field("startZ", "Início Z", value("startZ", 0))}
            ${field("control1X", "Controle 1 X", value("control1X", -1))}
            ${field("control1Y", "Controle 1 Y", value("control1Y", 1))}
            ${field("control1Z", "Controle 1 Z", value("control1Z", 0))}
            ${field("control2X", "Controle 2 X", value("control2X", 1))}
            ${field("control2Y", "Controle 2 Y", value("control2Y", -1))}
            ${field("control2Z", "Controle 2 Z", value("control2Z", 0))}
            ${field("endX", "Fim X", value("endX", 2))}
            ${field("endY", "Fim Y", value("endY", 0))}
            ${field("endZ", "Fim Z", value("endZ", 0))}
          </div>
        `;
        const geometryTypeSelect = fields.querySelector("[name='geometryType']");
        geometryTypeSelect.addEventListener("change", updateGeometryFieldVisibility);
        updateGeometryFieldVisibility();
      } else {
        fields.innerHTML = `
          ${labelField}
          ${field("steps", "Quantidade", editingObject?.values.steps ?? 5, "number", "1")}
          ${field("stepHeight", "Altura do degrau", editingObject?.values.stepHeight ?? 0.25)}
          ${field("stepDepth", "Profundidade", editingObject?.values.stepDepth ?? 0.5)}
          ${field("x", "Posição X", editingObject?.values.x ?? 0)}
          ${field("width", "Largura", editingObject?.values.width ?? 3)}
        `;
      }
      kindSelect.disabled = Boolean(editingObject);
      for (const option of kindSelect.options) {
        if (option.value === "player" || option.value === "ambient") {
          option.disabled = !editingObject || option.value !== editingObject.kind;
        }
      }
      submitButton.textContent = editingObject ? "Salvar alterações" : "Criar objeto";
    };

    const renderList = () => {
      const list = overlay.querySelector(".debug-list-items");
      const count = overlay.querySelector(".debug-object-count");
      count.textContent = this.objects.length;
      list.innerHTML = "";

      const startRename = (element, initialValue, save) => {
        const input = document.createElement("input");
        input.className = "debug-inline-rename";
        input.value = initialValue;
        input.setAttribute("aria-label", "Novo nome");
        input.addEventListener("input", () => input.setCustomValidity(""));
        let finished = false;
        const finish = (commit) => {
          if (finished) return;
          if (commit && save(input.value.trim(), input) === false) {
            input.focus();
            return;
          }
          finished = true;
          const label = document.createElement(element.tagName.toLowerCase());
          label.className = element.className;
          label.textContent = commit ? input.value.trim() : initialValue;
          input.replaceWith(label);
          renderList();
        };
        input.addEventListener("keydown", (event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            finish(true);
          } else if (event.key === "Escape") {
            event.preventDefault();
            finish(false);
          }
        });
        input.addEventListener("blur", () => finish(true));
        element.replaceWith(input);
        input.focus();
        input.select();
      };

      const readDraggedObject = (event) => {
        if (draggedObject) return draggedObject;
        const label = event.dataTransfer?.getData("text/plain");
        return this.objects.find((object) => object.label === label);
      };

      const moveObject = (object, target, groupId, after = false) => {
        if (!object || object === target) return;
        object.groupId = groupId || undefined;
        this.objects.splice(this.objects.indexOf(object), 1);
        const targetIndex = this.objects.indexOf(target);
        const insertIndex = targetIndex < 0
          ? this.objects.length
          : targetIndex + Number(after);
        this.objects.splice(insertIndex, 0, object);
        renderList();
      };

      const makeDraggable = (element, object) => {
        element.draggable = true;
        element.addEventListener("dragstart", (event) => {
          draggedObject = object;
          event.dataTransfer?.setData("text/plain", object.label);
          if (event.dataTransfer) event.dataTransfer.effectAllowed = "move";
          element.classList.add("is-dragging");
        });
        element.addEventListener("dragend", () => {
          draggedObject = null;
          element.classList.remove("is-dragging");
          list.querySelectorAll(".drop-target").forEach((target) => {
            target.classList.remove("drop-target");
          });
        });
        element.addEventListener("dragover", (event) => {
          event.preventDefault();
          element.classList.add("drop-target");
        });
        element.addEventListener("dragleave", (event) => {
          if (!element.contains(event.relatedTarget)) element.classList.remove("drop-target");
        });
        element.addEventListener("drop", (event) => {
          event.preventDefault();
          event.stopPropagation();
          element.classList.remove("drop-target");
          const draggedObject = readDraggedObject(event);
          if (!draggedObject) return;
          const bounds = element.getBoundingClientRect();
          const after = event.clientY > bounds.top + bounds.height / 2;
          moveObject(draggedObject, object, object.groupId, after);
        });
      };

      const renderObject = (object, grouped = false) => {
        const item = document.createElement("div");
        item.className = "debug-object-item";
        if (grouped) item.classList.add("is-group-member");
        item.dataset.objectLabel = object.label;
        makeDraggable(item, object);

        const name = document.createElement("div");
        name.className = "debug-object-name";
        const strong = document.createElement("strong");
        strong.textContent = object.label;
        strong.title = "Clique duas vezes para renomear";
        strong.addEventListener("dblclick", () => {
          startRename(strong, object.label, (nextLabel, input) => {
            if (!nextLabel) {
              input.setCustomValidity("Informe um nome para o objeto.");
              input.reportValidity();
              return false;
            }
            if (!this.IsLabelAvailable(nextLabel, object)) {
              input.setCustomValidity("Já existe um objeto com este nome.");
              input.reportValidity();
              return false;
            }
            object.label = nextLabel;
            object.values = { ...object.values, label: nextLabel };
            this.editorEngine?.selectionSystem?.refreshSelectionTools();
            return true;
          });
        });
        const kind = document.createElement("span");
        kind.textContent = object.kind;
        name.append(strong, kind);

        const actions = document.createElement("div");
        actions.className = "debug-object-actions";

        const editButton = document.createElement("button");
        editButton.type = "button";
        editButton.textContent = "Editar";
        editButton.addEventListener("click", () => {
          editingObject = object;
          kindSelect.value = object.kind;
          form.hidden = false;
          renderFields();
        });
        actions.append(editButton);

        const duplicateButton = document.createElement("button");
        duplicateButton.type = "button";
        duplicateButton.textContent = "Duplicar";
        duplicateButton.disabled = object.kind === "player";
        if (duplicateButton.disabled) {
          duplicateButton.title = "O player principal não pode ser duplicado.";
        }
        duplicateButton.addEventListener("click", () => {
          if (this.DuplicateObject(object)) renderList();
        });
        actions.append(duplicateButton);

        if (!object.permanent) {
          const deleteButton = document.createElement("button");
          deleteButton.type = "button";
          deleteButton.className = "danger";
          deleteButton.textContent = "Excluir";
          deleteButton.addEventListener("click", () => {
            if (!window.confirm(`Apagar o objeto "${object.label}"? Esta ação não pode ser desfeita.`)) {
              return;
            }
            this.DeleteObject(object, this.objects.indexOf(object));
            if (editingObject === object) {
              editingObject = null;
              form.hidden = true;
            }
            renderList();
          });

          actions.append(deleteButton);
        }

        item.append(name, actions);
        list.appendChild(item);
      };

      const renderGroup = (group) => {
        const groupItem = document.createElement("div");
        groupItem.className = "debug-object-group";
        groupItem.dataset.groupId = group.id;
        groupItem.addEventListener("dragover", (event) => {
          event.preventDefault();
          groupItem.classList.add("drop-target");
        });
        groupItem.addEventListener("dragleave", (event) => {
          if (!groupItem.contains(event.relatedTarget)) groupItem.classList.remove("drop-target");
        });
        groupItem.addEventListener("drop", (event) => {
          event.preventDefault();
          event.stopPropagation();
          groupItem.classList.remove("drop-target");
          const draggedObject = readDraggedObject(event);
          if (!draggedObject) return;
          moveObject(draggedObject, undefined, group.id);
        });

        const toggle = document.createElement("button");
        toggle.type = "button";
        toggle.className = "debug-group-toggle";
        toggle.textContent = group.collapsed ? "+" : "−";
        toggle.setAttribute("aria-label", group.collapsed ? "Expandir conjunto" : "Minimizar conjunto");
        toggle.addEventListener("click", () => {
          group.collapsed = !group.collapsed;
          renderList();
        });

        const name = document.createElement("strong");
        name.className = "debug-group-name";
        name.textContent = group.name;
        name.title = "Clique duas vezes para renomear";
        name.addEventListener("dblclick", () => {
          startRename(name, group.name, (nextName, input) => {
            const normalizedName = nextName.toLocaleLowerCase();
            if (!nextName) {
              input.setCustomValidity("Informe um nome para o conjunto.");
              input.reportValidity();
              return false;
            }
            if (this.objectGroups.some((other) =>
              other !== group && other.name.trim().toLocaleLowerCase() === normalizedName
            )) {
              input.setCustomValidity("Já existe um conjunto com este nome.");
              input.reportValidity();
              return false;
            }
            group.name = nextName;
            return true;
          });
        });

        const groupCount = document.createElement("span");
        groupCount.className = "debug-group-count";
        groupCount.textContent = this.objects.filter((object) => object.groupId === group.id).length;

        const groupActions = document.createElement("div");
        groupActions.className = "debug-group-actions";

        const duplicateGroupButton = document.createElement("button");
        duplicateGroupButton.type = "button";
        duplicateGroupButton.className = "debug-group-duplicate";
        duplicateGroupButton.textContent = "Duplicar";
        duplicateGroupButton.setAttribute("aria-label", `Duplicar conjunto ${group.name}`);
        duplicateGroupButton.addEventListener("click", (event) => {
          event.stopPropagation();
          if (this.DuplicateGroup(group)) renderList();
        });

        const deleteGroupButton = document.createElement("button");
        deleteGroupButton.type = "button";
        deleteGroupButton.className = "debug-group-delete";
        deleteGroupButton.textContent = "Apagar tudo";
        deleteGroupButton.setAttribute("aria-label", `Apagar conjunto ${group.name}`);
        deleteGroupButton.addEventListener("click", (event) => {
          event.stopPropagation();
          const members = this.objects.filter((object) => object.groupId === group.id);
          const removableCount = members.filter((object) => !object.permanent).length;
          const protectedCount = members.length - removableCount;
          const preservedMessage = protectedCount
            ? ` ${protectedCount} objeto(s) permanente(s) serão preservados fora do conjunto.`
            : "";
          const confirmation =
            `Apagar o conjunto "${group.name}" e seus ${removableCount} objeto(s)?${preservedMessage} Esta ação não pode ser desfeita.`;
          if (!window.confirm(confirmation)) return;

          if (editingObject && members.includes(editingObject) && !editingObject.permanent) {
            editingObject = null;
            form.hidden = true;
          }
          for (let index = this.objects.length - 1; index >= 0; index--) {
            const object = this.objects[index];
            if (object.groupId === group.id && !object.permanent) {
              this.DeleteObject(object, index);
            }
          }
          for (const object of this.objects) {
            if (object.groupId === group.id) object.groupId = undefined;
          }
          this.objectGroups = this.objectGroups.filter((candidate) => candidate !== group);
          renderList();
        });

        groupActions.append(duplicateGroupButton, deleteGroupButton);
        groupItem.append(toggle, name, groupCount, groupActions);
        list.appendChild(groupItem);

        if (!group.collapsed) {
          this.objects
            .filter((object) => object.groupId === group.id)
            .forEach((object) => renderObject(object, true));
        }
      };

      list.ondragover = (event) => {
        if (event.target !== list) return;
        event.preventDefault();
      };
      list.ondrop = (event) => {
        if (event.target !== list) return;
        event.preventDefault();
        const draggedObject = readDraggedObject(event);
        if (!draggedObject) return;
        draggedObject.groupId = undefined;
        this.objects.splice(this.objects.indexOf(draggedObject), 1);
        this.objects.push(draggedObject);
        renderList();
      };

      const renderedGroups = new Set();
      for (const object of this.objects) {
        const group = this.objectGroups.find((candidate) => candidate.id === object.groupId);
        if (group) {
          if (!renderedGroups.has(group.id)) {
            renderedGroups.add(group.id);
            renderGroup(group);
          }
        } else {
          renderObject(object);
        }
      }
      for (const group of this.objectGroups) {
        if (!renderedGroups.has(group.id)) renderGroup(group);
      }
    };

    developerControlsSelect.addEventListener("change", () => {
      this.developerCommandsEnabled = developerControlsSelect.value === "enabled";
    });

    skyboxFile.addEventListener("change", () => {
      const file = skyboxFile.files?.[0];
      skyboxFile.value = "";
      this.LoadSkyboxFile(file, skyboxStatus, skyboxRemove);
    });
    skyboxApply.addEventListener("click", () => {
      this.LoadSkyboxUrl(skyboxUrl.value, skyboxStatus, skyboxRemove);
    });
    skyboxUrl.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        this.LoadSkyboxUrl(skyboxUrl.value, skyboxStatus, skyboxRemove);
      }
    });
    skyboxRemove.addEventListener("click", () => {
      this.RemoveSkybox(skyboxStatus, skyboxRemove);
    });
    if (this.projectSkyboxSource) {
      this.LoadSkybox(this.projectSkyboxSource, skyboxStatus, skyboxRemove);
    }

    kindSelect.addEventListener("change", () => {
      editingObject = null;
      renderFields();
    });

    createButton.addEventListener("click", () => {
      editingObject = null;
      kindSelect.value = "wall";
      kindSelect.disabled = false;
      form.hidden = false;
      renderFields();
    });

    cancelFormButton.addEventListener("click", () => {
      editingObject = null;
      kindSelect.value = "wall";
      kindSelect.disabled = false;
      form.hidden = true;
      renderFields();
      renderList();
    });

    createGroupButton.addEventListener("click", () => {
      let groupNumber = this.objectGroups.length + 1;
      let name = `Conjunto ${groupNumber}`;
      const existingNames = new Set(
        this.objectGroups.map((group) => group.name.trim().toLocaleLowerCase())
      );
      while (existingNames.has(name.toLocaleLowerCase())) {
        groupNumber++;
        name = `Conjunto ${groupNumber}`;
      }
      this.objectGroups.push({
        id: crypto.randomUUID(),
        name,
        collapsed: false
      });
      renderList();
    });

    closeButton.addEventListener("click", () => this.CloseModal());
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const data = new FormData(form);
      const kind = kindSelect.value;
      const labelInput = form.elements.label;
      const label = String(data.get("label") ?? "").trim();

      labelInput.setCustomValidity("");
      if (!label) {
        labelInput.setCustomValidity("Informe um nome para o objeto.");
        labelInput.reportValidity();
        return;
      }
      if (!this.IsLabelAvailable(label, editingObject)) {
        labelInput.setCustomValidity("Já existe um objeto com este nome.");
        labelInput.reportValidity();
        return;
      }

      if (kind === "wall") {
        const values = {
          label,
          x: Number(data.get("x")),
          y: Number(data.get("y")),
          z: Number(data.get("z")),
          width: Number(data.get("width")),
          height: Number(data.get("height")),
          depth: Number(data.get("depth"))
        };
        if (editingObject) {
          this.UpdateWall(editingObject, values);
          editingObject = null;
        } else {
          this.AddWall(values);
        }
      } else if (kind === "light") {
        const values = {
          label,
          x: Number(data.get("x")),
          y: Number(data.get("y")),
          z: Number(data.get("z")),
          intensity: Number(data.get("intensity")),
          resolution: Number(data.get("resolution")),
          area: Number(data.get("area")),
          bias: Number(data.get("bias"))
        };
        if (editingObject) {
          this.UpdateLight(editingObject, values);
          editingObject = null;
        } else {
          this.AddLight(values);
        }
      } else if (kind === "ground") {
        const values = {
          label,
          horizontalLength: Number(data.get("horizontalLength")),
          verticalLength: Number(data.get("verticalLength")),
          materialType: String(data.get("materialType")),
          color: String(data.get("color")),
          metalness: Number(data.get("metalness")),
          roughness: Number(data.get("roughness")),
          shininess: Number(data.get("shininess")),
          side: String(data.get("side")),
          transparent: data.has("transparent"),
          opacity: Number(data.get("opacity")),
          wireframe: data.has("wireframe"),
          receiveShadow: data.has("receiveShadow")
        };
        if (editingObject) {
          this.UpdateGround(editingObject, values);
          editingObject = null;
        } else {
          this.AddGround(values);
        }
      } else if (kind === "ambient") {
        const values = {
          label,
          intensity: Number(data.get("intensity"))
        };
        this.UpdateAmbient(editingObject, values);
        editingObject = null;
      } else if (kind === "player") {
        const values = {
          label,
          horizontalLength: Number(data.get("radius")),
          verticalLength: Number(data.get("halfHeight")),
          x: Number(data.get("x")),
          y: Number(data.get("y")),
          z: Number(data.get("z")),
          shadows: data.has("shadows"),
          wireframePlayer: data.has("wireframePlayer"),
          wireframeCapsule: data.has("wireframeCapsule"),
          capsuleVisible: data.has("capsuleVisible"),
          capsuleTransparent: data.has("capsuleTransparent"),
          capsuleOpacity: Number(data.get("capsuleOpacity")),
          capsuleColor: String(data.get("capsuleColor")),
          transparent: data.has("transparent"),
          opacity: Number(data.get("opacity"))
        };
        this.UpdatePlayer(editingObject, values);
        editingObject = null;
      } else if (kind === "camera") {
        const values = {
          label,
          type: String(data.get("cameraMode")),
          x: Number(data.get("x")),
          y: Number(data.get("y")),
          z: Number(data.get("z")),
          lookAtX: Number(data.get("lookAtX")),
          lookAtY: Number(data.get("lookAtY")),
          lookAtZ: Number(data.get("lookAtZ"))
        };
        if (editingObject) {
          this.UpdateCamera(editingObject, values);
        } else {
          this.AddCamera(values);
        }
        editingObject = null;
      } else if (kind === "geometry") {
        const defaults = {
          width: 1, height: 1, depth: 1,
          radius: 0.5, widthSegments: 16, heightSegments: 12,
          radiusTop: 0.5, radiusBottom: 0.5, radialSegments: 12,
          length: 0.8, capSegments: 4, tube: 0.2, tubularSegments: 24,
          p: 2, q: 3, innerRadius: 0.25, outerRadius: 0.65,
          thetaSegments: 24, phiSegments: 1,
          startX: -2, startY: 0, startZ: 0,
          control1X: -1, control1Y: 1, control1Z: 0,
          control2X: 1, control2Y: -1, control2Z: 0,
          endX: 2, endY: 0, endZ: 0
        };
        const number = (name, fallback = 0) => {
          const value = data.get(name);
          return Number(value ?? editingObject?.values[name] ?? fallback);
        };
        const values = {
          label,
          geometryType: String(data.get("geometryType")),
          x: number("x"),
          y: number("y", 1),
          z: number("z"),
          rotationX: number("rotationX"),
          rotationY: number("rotationY"),
          rotationZ: number("rotationZ"),
          scaleX: number("scaleX", 1),
          scaleY: number("scaleY", 1),
          scaleZ: number("scaleZ", 1)
        };
        for (const [name, fallback] of Object.entries(defaults)) {
          values[name] = number(name, fallback);
        }

        const innerRadius = form.elements.innerRadius;
        if (innerRadius) innerRadius.setCustomValidity("");
        if (values.geometryType === "ring" && values.innerRadius >= values.outerRadius) {
          innerRadius.setCustomValidity("O raio interno precisa ser menor que o raio externo.");
          innerRadius.reportValidity();
          return;
        }

        if (editingObject) {
          this.editorEngine.updatePrimitive(editingObject, values);
          editingObject = null;
        } else {
          this.editorEngine.createPrimitive(values);
        }
      } else {
        const values = {
          label,
          steps: Number(data.get("steps")),
          stepHeight: Number(data.get("stepHeight")),
          stepDepth: Number(data.get("stepDepth")),
          x: Number(data.get("x")),
          width: Number(data.get("width"))
        };
        this.AddStair(values);
      }

      form.hidden = true;
      this.RefreshCameraOptions();
      renderFields();
      renderList();
    });

    button.addEventListener("click", () => this.OpenModal());
    document.addEventListener("pointerdown", (event) => {
      if (!overlay.classList.contains("open")
        || overlay.querySelector(".debug-modal").contains(event.target)
        || event.target === button) return;

      this.CloseModal();
      if (event.target === this.renderer?.domElement) {
        this.inputSystem?.setGameFocused(true);
      }
    });
    window.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        if (this.projectHubModal?.classList.contains("open")) {
          this.CloseProjectHubModal();
        } else if (this.settingsModal?.classList.contains("open")) {
          this.CloseSettingsModal();
        } else if (overlay.classList.contains("open")) {
          this.CloseModal();
        }
      }
      if (this.gameMode === "play" && event.code === "KeyO" && !event.repeat) {
        event.preventDefault();
        this.SetGameMode("edit");
        return;
      }

      if (this.gameMode !== "edit" || event.repeat
        || event.target.closest?.("input, select, textarea, button, [contenteditable='true']")) {
        return;
      }

      const transformModes = {
        KeyM: "translate",
        KeyR: "rotate",
        KeyE: "scale"
      };
      const transformMode = transformModes[event.code];
      if (transformMode) {
        event.preventDefault();
        this.editorEngine?.setTransformMode(transformMode);
      }
    });

    renderFields();
    renderList();
    this.UpdateModalModeControls();
    this.OpenModal();
  }

  LoadSkyboxFile(file, status, removeButton) {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      status.textContent = "Selecione um arquivo de imagem.";
      return;
    }

    const reader = new FileReader();
    reader.onload = () => this.LoadSkybox(String(reader.result), status, removeButton);
    reader.onerror = () => {
      status.textContent = "Não foi possível ler o arquivo de imagem.";
    };
    reader.readAsDataURL(file);
  }

  LoadSkyboxUrl(value, status, removeButton) {
    const source = value.trim();
    if (!source) {
      status.textContent = "Informe a URL de uma imagem.";
      return;
    }

    let url;
    try {
      url = new URL(source, window.location.href);
    } catch {
      status.textContent = "A URL da imagem não é válida.";
      return;
    }
    if (!["http:", "https:"].includes(url.protocol)) {
      status.textContent = "Use uma URL HTTP ou HTTPS para a imagem.";
      return;
    }

    this.LoadSkybox(url.href, status, removeButton);
  }

  LoadSkybox(url, status, removeButton) {
    const request = ++this.skyboxLoadRequest;
    status.textContent = "Carregando skybox...";
    const loader = new THREE.TextureLoader();
    let texture;

    texture = loader.load(
      url,
      (loadedTexture) => {
        if (request !== this.skyboxLoadRequest) {
          loadedTexture.dispose();
          releaseObjectUrl();
          return;
        }

        loadedTexture.colorSpace = THREE.SRGBColorSpace;
        loadedTexture.mapping = THREE.EquirectangularReflectionMapping;
        loadedTexture.needsUpdate = true;
        const previousTexture = this.skyboxTexture;
        this.skyboxTexture = loadedTexture;
        this.scene.background = loadedTexture;
        this.projectSkyboxSource = url;
        previousTexture?.dispose();
        removeButton.disabled = false;
        status.textContent = "Skybox aplicada.";
      },
      undefined,
      () => {
        if (request === this.skyboxLoadRequest) {
          status.textContent =
            "Não foi possível carregar a imagem. Verifique a URL, o formato e o CORS.";
        }
        texture?.dispose();
      }
    );
  }

  RemoveSkybox(status, removeButton) {
    this.skyboxLoadRequest++;
    if (this.skyboxTexture) {
      if (this.scene.background === this.skyboxTexture) {
        this.scene.background = this.originalSceneBackground;
      }
      this.skyboxTexture.dispose();
      this.skyboxTexture = undefined;
    }
    this.projectSkyboxSource = null;
    removeButton.disabled = true;
    status.textContent = "Skybox removida.";
  }

  OpenModal() {
    if (!this.modal) this.Modal();
    if (this.gameMode === "play") return;
    this.UpdateModalModeControls();
    this.inputSystem?.setGameFocused(false);
    if (document.pointerLockElement === this.renderer.domElement) {
      document.exitPointerLock();
    }
    this.modal.classList.add("open");
    this.modal.setAttribute("aria-hidden", "false");
  }

  CloseModal() {
    if (!this.modal || this.gameMode === "edit") return;
    this.modal.classList.remove("open");
    this.modal.setAttribute("aria-hidden", "true");
    this.inputSystem?.setGameFocused(false);
  }

  UpdateModalModeControls() {
    if (!this.modal) return;
    this.modal.querySelector(".debug-modal-close").hidden = true;
    if (this.modalButton) this.modalButton.hidden = true;
  }

  IsLabelAvailable(label, editingObject = null) {
    const normalizedLabel = label.trim().toLocaleLowerCase();
    return !this.objects.some((object) => {
      if (object === editingObject) return false;
      return object.label.trim().toLocaleLowerCase() === normalizedLabel;
    });
  }

  GetNextLabel(prefix) {
    let index = 1;
    let label = `${prefix} ${index}`;
    while (!this.IsLabelAvailable(label)) {
      index++;
      label = `${prefix} ${index}`;
    }
    return label;
  }

  GetCopyLabel(label) {
    const baseLabel = `${label} (cópia)`;
    let copyLabel = baseLabel;
    let suffix = 2;
    while (!this.IsLabelAvailable(copyLabel)) {
      copyLabel = `${baseLabel} ${suffix++}`;
    }
    return copyLabel;
  }

  DuplicateObject(object, groupId = object.groupId) {
    if (object.kind === "player") return undefined;

    const values = JSON.parse(JSON.stringify(object.values));
    values.label = this.GetCopyLabel(object.label);
    if (typeof values.x === "number") values.x += 1;
    if (object.kind === "camera" && values.type !== "follow"
        && values.type !== "firstPerson"
        && typeof values.lookAtX === "number") {
      values.lookAtX += 1;
    }

    if (object.kind === "camera") {
      this.AddCamera(values, false);
    } else if (object.kind === "ground") {
      this.AddGround(values);
    } else if (object.kind === "wall") {
      this.AddWall(values);
    } else if (object.kind === "stair") {
      this.AddStair(values);
    } else if (object.kind === "light") {
      this.AddLight(values);
    } else if (object.kind === "ambient") {
      const entity = createAmbientLight(this.world, { intensity: values.intensity });
      this.objects.push({
        kind: "ambient",
        label: values.label,
        entity,
        permanent: false,
        values
      });
    } else if (object.kind === "geometry") {
      this.AddGeometry(values);
    } else {
      return undefined;
    }

    const duplicate = this.objects.at(-1);
    if (!duplicate || duplicate.label !== values.label) return undefined;
    if (groupId !== undefined) duplicate.groupId = groupId;

    const snapshots = this.editorEngine?.serializeObject(object) ?? [];
    if (snapshots.length) {
      const shiftedSnapshots = snapshots.map((snapshot) => {
        const copy = JSON.parse(JSON.stringify(snapshot));
        if (copy.transform?.position?.length === 3) copy.transform.position[0] += 1;
        return copy;
      });
      this.editorEngine.syncObjects();
      this.editorEngine.restoreObjectState(duplicate, shiftedSnapshots);
      if (["wall", "geometry"].includes(duplicate.kind)
          && shiftedSnapshots[0]?.transform?.position?.length === 3) {
        const [x, y, z] = shiftedSnapshots[0].transform.position;
        duplicate.values = { ...duplicate.values, x, y, z };
      }
    }

    this.RefreshCameraOptions();
    return duplicate;
  }

  DuplicateGroup(group) {
    const baseName = `${group.name} (cópia)`;
    let name = baseName;
    let suffix = 2;
    while (this.objectGroups.some((candidate) =>
      candidate.name.trim().toLocaleLowerCase() === name.toLocaleLowerCase()
    )) {
      name = `${baseName} ${suffix++}`;
    }

    const duplicateGroup = {
      id: crypto.randomUUID(),
      name,
      collapsed: group.collapsed
    };
    this.objectGroups.push(duplicateGroup);
    let skippedPlayer = false;
    for (const object of this.objects.filter((candidate) => candidate.groupId === group.id)) {
      if (object.kind === "player") {
        skippedPlayer = true;
        continue;
      }
      this.DuplicateObject(object, duplicateGroup.id);
    }
    if (skippedPlayer) {
      window.alert("O player principal não foi duplicado; os outros objetos do conjunto foram copiados.");
    }
    return duplicateGroup;
  }

  UpdatePlayer(object, values) {
    const transform = this.world.getComponent(object.entity, Transform);
    const mesh = this.world.getComponent(object.entity, Mesh);
    const capsule = this.world.getComponent(object.entity, CapsuleCollider);
    const debugMesh = this.world.getComponent(object.entity, CapsuleDebugMesh);
    const radius = values.horizontalLength;
    const halfHeight = values.verticalLength;

    transform.x = values.x;
    transform.y = values.y;
    transform.z = values.z;

    mesh.mesh.geometry.dispose();
    mesh.mesh.geometry = new THREE.BoxGeometry(
      radius * 2,
      halfHeight * 2 + radius * 2,
      radius * 2
    );
    mesh.mesh.castShadow = values.shadows;
    mesh.mesh.material.wireframe = values.wireframePlayer;
    mesh.mesh.material.transparent = values.transparent;
    mesh.mesh.material.opacity = values.opacity;
    mesh.mesh.material.depthWrite = !values.transparent;
    mesh.mesh.material.needsUpdate = true;

    debugMesh.mesh.geometry.dispose();
    debugMesh.mesh.geometry = new THREE.CapsuleGeometry(
      radius,
      halfHeight * 2,
      8,
      16
    );
    debugMesh.mesh.material.wireframe = values.wireframeCapsule;
    debugMesh.mesh.material.transparent = values.capsuleTransparent;
    debugMesh.mesh.material.opacity = values.capsuleOpacity;
    debugMesh.mesh.material.color.set(values.capsuleColor);
    debugMesh.mesh.material.depthWrite = !values.capsuleTransparent;
    debugMesh.mesh.visible = values.capsuleVisible || values.wireframeCapsule;
    debugMesh.mesh.material.depthTest = true;
    debugMesh.mesh.material.needsUpdate = true;

    object.label = values.label;
    object.values = { ...values };
    if (this.editorEngine) {
      this.editorEngine.syncPlayerCollider(object.entity);
    } else {
      capsule.radius = radius * Math.max(Math.abs(transform.scaleX), Math.abs(transform.scaleZ));
      capsule.height = halfHeight * 2 * Math.abs(transform.scaleY);
    }
    this.editorEngine?.markGameEntityDirty(object.entity);
  }

  UpdateAmbient(object, values) {
    const data = this.world.getComponent(object.entity, AmbientLightComponent);
    data.intensity = values.intensity;
    object.label = values.label;
    object.values = { ...values };
  }

  AddCamera(values, permanent = false) {
    let entity;
    if (values.type === "follow") {
      entity = createFollowCamera(this.world, this.player);
    } else if (values.type === "firstPerson") {
      entity = createFirstPersonCamera(this.world, this.player);
    } else {
      //cria câmera estática
      entity = this.world.createEntity();
      this.world.addComponent(entity, new CameraRig());
    }

    const object = {
      kind: "camera",
      label: values.label,
      entity,
      permanent,
      viewCamera: new THREE.PerspectiveCamera(
        this.projectSettings.cameraFov,
        this.width / this.height,
        0.1,
        this.projectSettings.renderDistance
      ),
      values: { ...values }
    };
    this.objects.push(object);
    if (!this.selectedGameCamera) this.selectedGameCamera = object;

    this.UpdateCamera(object, values);
    return entity;
  }

  UpdateCamera(object, values) {
    const rig = this.world.getComponent(object.entity, CameraRig);
    const transform = this.world.getComponent(this.player, Transform);
    let follow = this.world.getComponent(object.entity, CameraFollow);
    const viewCamera = object.viewCamera;

    viewCamera.position.set(values.x, values.y, values.z);

    if (values.type === "follow") {
      if (!follow) {
        follow = new CameraFollow({ mode: "follow" });
        this.world.addComponent(object.entity, follow);
      }

      follow.mode = "follow";
      follow.offsetX = values.x;
      follow.offsetY = values.y;
      follow.offsetZ = values.z;
      follow.smoothness = 8;
      follow.lookAtHeight = 1;
      const targetY = transform.y + follow.lookAtHeight;
      const dx = values.x - transform.x;
      const dy = values.y - targetY;
      const dz = values.z - transform.z;
      rig.distance = Math.max(0.001, Math.hypot(dx, dy, dz));
      rig.yaw = Math.atan2(dx, dz);
      rig.pitch = Math.asin(Math.max(-1, Math.min(1, dy / rig.distance)));
      rig.target = this.player;
      viewCamera.lookAt(transform.x, targetY, transform.z);
    } else if (values.type === "firstPerson") {
      if (!follow) {
        follow = new CameraFollow({ mode: "firstPerson" });
        this.world.addComponent(object.entity, follow);
      }

      follow.mode = "firstPerson";
      follow.offsetX = values.x ?? 0;
      follow.offsetY = values.y ?? 1.6;
      follow.offsetZ = values.z ?? 0;
      follow.smoothness = 20;
      follow.lookAtHeight = 0;
      rig.target = this.player;

      const cameraX = transform.x + follow.offsetX;
      const cameraY = transform.y + follow.offsetY;
      const cameraZ = transform.z + follow.offsetZ;
      const directionX = values.lookAtX ?? 0;
      const directionY = values.lookAtY ?? 0;
      const directionZ = values.lookAtZ ?? -1;
      rig.yaw = Math.atan2(-directionX, -directionZ);
      rig.pitch = Math.atan2(
        directionY,
        Math.hypot(directionX, directionZ)
      );
      rig.distance = 1;
      viewCamera.position.set(cameraX, cameraY, cameraZ);
      const horizontalScale = Math.cos(rig.pitch);
      viewCamera.lookAt(
        cameraX - Math.sin(rig.yaw) * horizontalScale,
        cameraY + Math.sin(rig.pitch),
        cameraZ - Math.cos(rig.yaw) * horizontalScale
      );
    } else {
      if (follow) {
        this.world.removeComponent(object.entity, CameraFollow);
      }
      if (values.type === "birdseye") {
        viewCamera.up.set(0, 0, -1);
      } else {
        viewCamera.up.set(0, 1, 0);
      }
      viewCamera.lookAt(values.lookAtX, values.lookAtY, values.lookAtZ);
      rig.yaw = Math.atan2(values.x - values.lookAtX, values.z - values.lookAtZ);
    }

    object.label = values.label;
    object.values = { ...values };
    this.RefreshCameraOptions();
  }

  RefreshCameraOptions() {
    const cameras = this.objects.filter((object) => object.kind === "camera");
    const selectedCameraRemoved = !cameras.includes(this.selectedGameCamera);
    if (selectedCameraRemoved) {
      this.selectedGameCamera = cameras[0];
    }
    if (!this.gameModeSelect) return;

    const previousValue = this.gameModeSelect.value || "free";
    this.gameModeSelect.replaceChildren();

    const freeOption = document.createElement("option");
    freeOption.value = "free";
    freeOption.textContent = "Câmera livre";
    this.gameModeSelect.appendChild(freeOption);

    for (const object of cameras) {
      const option = document.createElement("option");
      option.value = String(object.entity);
      option.textContent = object.label;
      this.gameModeSelect.appendChild(option);
    }

    this.gameModeSelect.value = cameras.some(
      (object) => String(object.entity) === previousValue
    ) || previousValue === "free" ? previousValue : "free";

    if (this.gameModeButton) {
      this.gameModeButton.disabled = cameras.length === 0;
    }

    if (this.gameMode === "edit") {
      this.SelectEditorCamera(this.gameModeSelect.value);
    } else if (!this.selectedGameCamera) {
      this.SetGameMode("edit");
    } else if (selectedCameraRemoved) {
      this.SetActiveCamera(
        this.selectedGameCamera.viewCamera,
        this.selectedGameCamera.entity,
        "play"
      );
    }
  }

  SelectEditorCamera(value) {
    if (this.gameMode !== "edit") return;

    if (value === "free") {
      this.SetActiveCamera(this.editorCamera, undefined, "editor-free");
      return;
    }

    const object = this.objects.find(
      (candidate) => candidate.kind === "camera"
        && String(candidate.entity) === value
    );
    if (!object) {
      this.gameModeSelect.value = "free";
      this.SetActiveCamera(this.editorCamera, undefined, "editor-free");
      return;
    }

    this.selectedGameCamera = object;
    this.SetActiveCamera(object.viewCamera, object.entity, "preview");
  }

  SetActiveCamera(camera, entity, controlMode) {
    this.camera = camera;
    if (this.renderSystem) this.renderSystem.camera = camera;
    if (this.orbitCameraSystem) {
      this.orbitCameraSystem.camera = camera;
      this.orbitCameraSystem.activeEntity = entity;
    }
    if (this.mouseLookSystem) {
      this.mouseLookSystem.setEditorCamera(this.editorCamera, this.inputSystem);
      this.mouseLookSystem.activeEntity = entity;
      this.mouseLookSystem.setMode(controlMode);
    }
    this.editorEngine?.setCamera(camera, controlMode);
    if (this.cameraBasisSystem) this.cameraBasisSystem.activeCameraEntity = entity;
    if (this.cameraAimSystem) this.cameraAimSystem.activeCameraEntity = entity;
  }

  SetGameMode(mode) {
    if (mode === "play") {
      const camera = this.selectedGameCamera
        ?? this.objects.find((object) => object.kind === "camera");
      if (!camera) return;

      this.selectedGameCamera = camera;
      this.gameMode = "play";
      for (const system of this.simulationSystems) system.enabled = true;
      this.inputSystem?.setPlayerInputEnabled(true);
      this.SetActiveCamera(camera.viewCamera, camera.entity, "play");
      this.editorEngine?.setMode("play");
      this.gameModeSelect.hidden = true;
      this.gameModeButton.textContent = "EDIÇÃO";
      this.inputSystem?.setGameFocused(false);
      this.UpdateModalModeControls();
      this.CloseModal();
      return;
    }

    this.gameMode = "edit";
    for (const system of this.simulationSystems) system.enabled = false;
    this.inputSystem?.setPlayerInputEnabled(false);
    this.inputSystem?.setGameFocused(false);
    if (document.pointerLockElement === this.renderer.domElement) {
      document.exitPointerLock();
    }
    this.gameModeSelect.hidden = false;
    this.gameModeButton.textContent = "JOGAR";
    this.SelectEditorCamera(this.gameModeSelect.value || "free");
    this.editorEngine?.setMode("edit");
    this.OpenModal();
  }

  StateGround(HorizontalLenght, VerticalLenght, label = "Chão", permanent = true, materialSettings = {}) {
    const existingObject = this.FindCodeSetupDuplicate(label);
    if (existingObject) return existingObject.entity;

    const values = {
      horizontalLength: HorizontalLenght,
      verticalLength: VerticalLenght,
      materialType: materialSettings.materialType ?? "standard",
      color: materialSettings.color ?? "#ffffff",
      metalness: materialSettings.metalness ?? 0,
      roughness: materialSettings.roughness ?? 1,
      shininess: materialSettings.shininess ?? 30,
      side: materialSettings.side ?? "front",
      transparent: materialSettings.transparent ?? false,
      opacity: materialSettings.opacity ?? 1,
      wireframe: materialSettings.wireframe ?? false,
      receiveShadow: materialSettings.receiveShadow ?? true
    };
    const entity = createGround(
      this.world,
      this.scene,
      HorizontalLenght,
      VerticalLenght,
      values
    );
    this.objects.push({
      kind: "ground",
      label,
      entity,
      permanent,
      values
    });
    return entity;
  }

  PlaceWall(xPos, yPos, zPos, width, height, diameter, label) {
    const existingObject = this.FindCodeSetupDuplicate(label);
    if (existingObject) return existingObject.entity;

    const objectLabel = label ?? this.GetNextLabel("Parede");
    const entity = createWall(this.world, this.scene, { x: xPos, y: yPos, z: zPos, w: width, h: height, d: diameter});
    this.objects.push({
      kind: "wall",
      label: objectLabel,
      entity,
      permanent: false,
      values: { x: xPos, y: yPos, z: zPos, width, height, depth: diameter }
    });
    return entity;
  }

  PlaceStair(steps, stepHeight, stepDiameter, xPos, width, label) {
    const objectLabel = label ?? this.GetNextLabel("Escada");
    const existingObject = this.FindCodeSetupDuplicate(objectLabel);
    if (existingObject) return;

    const entities = [];
    for(let i = 0; i < steps; i++) {
      const entity = createWall(this.world, this.scene, {
        x: xPos, 
        y: (stepHeight / 2) + i * stepHeight, 
        z: 2 + i * stepDiameter, 
        w: width, 
        h: stepHeight, 
        d: stepDiameter});
      entities.push(entity);
    }
    this.objects.push({
      kind: "stair",
      label: objectLabel,
      entities,
      permanent: false,
      values: { label: objectLabel, steps, stepHeight, stepDepth: stepDiameter, x: xPos, width }
    });
  }

  PlaceLight(xPos, yPos, zPos, intensity, resolution, area, bias, type, label) {
    const objectLabel = label
      ?? (type === "ambient" ? "Luz ambiente" : this.GetNextLabel("Luz direcional"));
    const existingObject = this.FindCodeSetupDuplicate(objectLabel);
    if (existingObject) return existingObject.entity;

    let entity;
    if(type == "directional") {
      entity = createDirectionalLight(this.world, { x: xPos, y: yPos, z: zPos, intensity: intensity, resolution: resolution, area: area, bias: bias});
      this.objects.push({
        kind: "light",
        label: objectLabel,
        entity,
        permanent: false,
        values: { x: xPos, y: yPos, z: zPos, intensity, resolution, area, bias }
      });
    } else if(type == "ambient") {
      entity = createAmbientLight(this.world, { intensity: intensity });
      this.objects.push({
        kind: "ambient",
        label: objectLabel,
        entity,
        permanent: true,
        values: { intensity }
      });
    }
    return entity;
  }

  AddWall(values) {
    return this.PlaceWall(
      values.x,
      values.y,
      values.z,
      values.width,
      values.height,
      values.depth,
      values.label
    );
  }

  AddGeometry(values) {
    const existingObject = this.FindCodeSetupDuplicate(values.label);
    if (existingObject) return existingObject.entity;

    const record = createEditorPrimitive(this.world, this.scene, values);
    this.objects.push(record);
    return record.entity;
  }

  UpdateWall(object, values) {
    const transform = this.world.getComponent(object.entity, Transform);
    const mesh = this.world.getComponent(object.entity, Mesh);
    const collider = this.world.getComponent(object.entity, ColliderAABB);

    transform.x = values.x;
    transform.y = values.y;
    transform.z = values.z;

    mesh.mesh.geometry.dispose();
    mesh.mesh.geometry = new THREE.BoxGeometry(
      values.width,
      values.height,
      values.depth
    );
    mesh.mesh.position.set(values.x, values.y, values.z);

    collider.halfX = values.width / 2;
    collider.halfY = values.height / 2;
    collider.halfZ = values.depth / 2;

    object.values = { ...values };
    object.label = values.label;
    this.editorEngine?.markGameEntityDirty(object.entity);
  }

  AddLight(values) {
    return this.PlaceLight(
      values.x,
      values.y,
      values.z,
      values.intensity,
      values.resolution,
      values.area,
      values.bias,
      "directional",
      values.label
    );
  }

  UpdateLight(object, values) {
    const transform = this.world.getComponent(object.entity, Transform);
    const data = this.world.getComponent(object.entity, DirectionalLightComponent);

    transform.x = values.x;
    transform.y = values.y;
    transform.z = values.z;
    data.intensity = values.intensity;
    data.Setting(values.resolution, values.area, values.bias);

    object.values = { ...values };
    object.label = values.label;
  }

  AddGround(values) {
    return this.StateGround(
      values.horizontalLength,
      values.verticalLength,
      values.label,
      false,
      values
    );
  }

  UpdateGround(object, values) {
    const mesh = this.world.getComponent(object.entity, Mesh);
    const collider = this.world.getComponent(object.entity, ColliderAABB);

    mesh.mesh.geometry.dispose();
    mesh.mesh.geometry = new THREE.PlaneGeometry(
      values.horizontalLength,
      values.verticalLength
    );

    collider.halfX = values.horizontalLength / 2;
    collider.halfY = 0.009;
    collider.halfZ = values.verticalLength / 2;

    const previousMaterial = mesh.mesh.material;
    mesh.mesh.material = createGroundMaterial(values);
    previousMaterial.dispose();
    mesh.mesh.receiveShadow = values.receiveShadow;
    object.values = { ...values };
    object.label = values.label;
    this.editorEngine?.markGameEntityDirty(object.entity);
  }

  AddStair(values) {
    this.PlaceStair(
      values.steps,
      values.stepHeight,
      values.stepDepth,
      values.x,
      values.width,
      values.label,
      values.label
    );
  }

  DeleteObject(object, index) {
    if (object.permanent) return;

    const entities = object.entities ?? [object.entity];

    for (const entity of entities) {
      if (entity === undefined) continue;
      this.editorEngine?.unregisterGameEntity(entity);

      const mesh = this.world.getComponent(entity, Mesh);
      if (mesh?.mesh) {
        this.scene.remove(mesh.mesh);
        mesh.mesh.geometry?.dispose();
        mesh.mesh.material?.dispose();
      }

      const debugMesh = this.world.getComponent(entity, CapsuleDebugMesh);
      if (debugMesh?.mesh) {
        this.scene.remove(debugMesh.mesh);
        debugMesh.mesh.geometry?.dispose();
        debugMesh.mesh.material?.dispose();
      }

      const lightHandle = this.world.getComponent(entity, LightHandle);
      if (lightHandle?.light) {
        this.scene.remove(lightHandle.light);
      }

      this.world.destroyEntity(entity);
    }

    if (Number.isInteger(index)) {
      this.objects.splice(index, 1);
    }
    this.RefreshCameraOptions();
  }

  initialize() {

    //primeiro vem o input, a chamada para a ação
    //segundamente vem a tradução desses dados em informações legíveis pelo sistema
    //depois o sistema de movimentos acrescenta lógica de física e dinâmica
    //por fim, e só ultimamente, as informações são renderizados

    //Ou seja, a pipeline é: INPUT -> CONTROLLER -> PHYSICS && MOVEMENT -> RENDERING
    //A ordem em que os sistemas são adicionados IMPORTA.

    // 1) INPUT (collects raw input)
    this.inputSystem = new InputSystem(this.renderer.domElement);
    this.inputSystem.setPlayerInputEnabled(this.gameMode === "play");
    this.world.addSystem(this.inputSystem);
    this.mouseLookSystem = new MouseLookSystem(this.renderer.domElement);
    this.mouseLookSystem.setEditorCamera(this.editorCamera, this.inputSystem);
    this.mouseLookSystem.setMode("editor-free");
    this.world.addSystem(this.mouseLookSystem); // NEW (camera mouse input)
    this.simulationSystems = [];
    const addSimulationSystem = (system) => {
      system.enabled = this.gameMode === "play";
      this.simulationSystems.push(system);
      this.world.addSystem(system);
    };

    // 2) MODE | STATE
    addSimulationSystem(new ModeSwitchSystem());

    // 3) CONTROLLERS (turn intent into velocity)
    addSimulationSystem(new PlayerControllerSystem());

    // 4) FORCES
    addSimulationSystem(new GravitySystem());

    // 5) INTEGRATION (apply velocity to position)
    addSimulationSystem(new MovementSystem());

    // 6) COLLISION (resolve penetrations, adjust position & velocity)
    addSimulationSystem(new CapsuleVsAABBCollisionSystem()); // player vs world
    // this.world.addSystem(new GroundSystem());
    addSimulationSystem(new StepClimbSystem());
    addSimulationSystem(new GroundSnapSystem());
    addSimulationSystem(new AABBCollisionSystem()); // other boxes, props, etc

    this.editorEngine = new EditorEngine({
      gameWorld: this.world,
      scene: this.scene,
      canvas: this.renderer.domElement,
      camera: this.camera,
      objectRecords: this.objects,
      selectionTools: this.modal.querySelector(".editor-selection-tools"),
      selectionName: this.modal.querySelector(".editor-selection-name"),
      materialEditor: this.modal.querySelector(".editor-material-editor"),
      transformModeButtons: [...this.modal.querySelectorAll("[data-transform-mode]")],
      onTransformDragging: (dragging, cameraMode) => {
        this.mouseLookSystem.setMode(dragging ? "transform" : cameraMode);
      }
    });
    for (const [object, snapshots] of this.pendingObjectSnapshots) {
      this.editorEngine.restoreObjectState(object, snapshots);
    }
    this.pendingObjectSnapshots = [];
    this.world.addSystem(new EditorBridgeSystem(this.editorEngine));

    // 7) CAMERA (must run AFTER movement & collisions)
    this.orbitCameraSystem = new OrbitCameraSystem(this.camera);
    this.world.addSystem(this.orbitCameraSystem);
    this.cameraBasisSystem = new CameraBasisSystem();
    addSimulationSystem(this.cameraBasisSystem);
    this.cameraAimSystem = new CameraAimSystem();
    addSimulationSystem(this.cameraAimSystem);

    // 8) LIGHTING (follow camera or scene)
    this.world.addSystem(new LightSystem(this.scene));

    // 9) RENDER (last, always)
    this.renderSystem = new RenderSystem(this.renderer, this.scene, this.camera);
    this.world.addSystem(this.renderSystem);
    this.SetActiveCamera(this.editorCamera, undefined, "editor-free");

    window.addEventListener("resize", () => {
      const aspect = window.innerWidth / window.innerHeight;
      this.editorCamera.aspect = aspect;
      this.editorCamera.updateProjectionMatrix();
      for (const object of this.objects) {
        if (object.kind === "camera") {
          object.viewCamera.aspect = aspect;
          object.viewCamera.updateProjectionMatrix();
        }
      }

      this.renderer.setSize(window.innerWidth, window.innerHeight);
      this.renderer.setPixelRatio(window.devicePixelRatio);
    });

    document.addEventListener("pointerlockchange", () => {
      document.body.classList.toggle(
        "locked",
        document.pointerLockElement === this.renderer.domElement
      );
    });
  }

  CountChildren() {
    //computa quantas entidade foram criadas na cena
    console.log("scene children count: ", this.scene.children.length);
  }

  DebugTools(globalState){
    if(globalState == "on") {
      this.axes = new THREE.AxesHelper(3);
      this.scene.add(this.axes);
      this.axes.visible = false; //tira os eixos por padrão
      
      this.grid = new THREE.GridHelper(50, 50);
      this.scene.add(this.grid);
      this.grid.visible = false; //tira o grid por padrão
      
      this.AxesSwitch("on");
      this.GridSwitch("on");
    } else if(globalState == "off") {
      //nothing happens
    }
  }

  AxesSwitch(state) {
    if(state == "on") {
      window.addEventListener("keydown", e => {
        if (this.developerCommandsEnabled && this.inputSystem?.gameFocused
          && !e.repeat && e.code === "KeyH") {
          this.axes.visible = !this.axes.visible;
        }
      });
    } else if(state == "off") {
      //nothing happens
    }
  }

  GridSwitch(state) {
    if(state == "on") {
      window.addEventListener("keydown", e => {
        if (this.developerCommandsEnabled && this.inputSystem?.gameFocused
          && !e.repeat && e.code === "KeyG") {
          this.grid.visible = !this.grid.visible;
        }
      });
    } else if(state == "off") {
      //nothing happens
    }
  }

  gameLoop() {
    const now = performance.now();
    const deltaTime = (now - this.lastTime) / 1000;
    this.lastTime = now;

    // movementSystem.update(world, deltaTime);

    // renderer.render(scene, camera);
    this.world.update(deltaTime);
    requestAnimationFrame(() => this.gameLoop());
  }
}