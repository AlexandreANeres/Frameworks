import * as THREE from "three";
import { Transform } from "../components/Transform.js";
import { Mesh } from "../components/Mesh.js";
import { ColliderAABB } from "../components/ColliderAABB.js";
import { StaticBody } from "../components/StaticBody.js";

const groundMaterialTypes = {
    standard: THREE.MeshStandardMaterial,
    phong: THREE.MeshPhongMaterial,
    lambert: THREE.MeshLambertMaterial,
    basic: THREE.MeshBasicMaterial
};

export function createGroundMaterial(settings = {}) {
    const Material = groundMaterialTypes[settings.materialType] ?? THREE.MeshStandardMaterial;
    const side = {
        front: THREE.FrontSide,
        double: THREE.DoubleSide,
        back: THREE.BackSide
    }[settings.side] ?? THREE.FrontSide;
    const common = {
        color: settings.color ?? "#ffffff",
        side,
        transparent: settings.transparent ?? false,
        opacity: settings.opacity ?? 1,
        wireframe: settings.wireframe ?? false
    };

    if (Material === THREE.MeshStandardMaterial) {
        return new Material({
            ...common,
            metalness: settings.metalness ?? 0,
            roughness: settings.roughness ?? 1
        });
    }
    if (Material === THREE.MeshPhongMaterial) {
        return new Material({ ...common, shininess: settings.shininess ?? 30 });
    }
    return new Material(common);
}

export function createGround(world, scene, x = 50, y = 50, settings = {}) {
    const entity = world.createEntity();

    // Visual
    const geometry = new THREE.PlaneGeometry(x, y);
    const material = createGroundMaterial(settings);
    const plane = new THREE.Mesh(geometry, material);

    plane.rotation.x = -Math.PI / 2;

    // Acréscimo de sombras
    plane.receiveShadow = settings.receiveShadow ?? true;

    scene.add(plane);

    // ECS data
    world.addComponent(entity, new Transform(0, 0, 0, -Math.PI / 2));
    world.addComponent(entity, new Mesh(plane));
    world.addComponent(entity, new StaticBody());

    // Collider: a big thin box
    world.addComponent(entity, new ColliderAABB(x / 2, 0.009, y / 2));
    
    return entity;
}