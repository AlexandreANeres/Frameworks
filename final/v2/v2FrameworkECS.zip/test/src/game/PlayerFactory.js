import * as THREE from "three";
import { Transform } from "../components/Transform.js";
import { Velocity } from "../components/Velocity.js";
import { Mesh } from "../components/Mesh.js";
import { Health } from "../components/Health.js";
import { Input } from "../components/Input.js";
import { PlayerControlled } from "../components/PlayerControlled.js";
import { ControllerSettings } from "../components/ControllerSetting.js";
import { Grounded } from "../components/Grounded.js";
import { ColliderAABB } from "../components/ColliderAABB.js";
import { DynamicBody } from "../components/DynamicBody.js";
import { CapsuleCollider } from "../components/CapsuleCollider.js";
import { ControlMode } from "../components/ControlMode.js";
import { Aim } from "../components/Aim.js";
import { CameraBasis } from "../components/CameraBasis.js";
import { CapsuleDebugMesh } from "../components/CapsuleDebugMesh.js";

//Factories => will handle entity creation

export function createPlayer(world, scene, ShadowsState = true, HorizontalLenght = 0.5, VerticalLenght = 0.5, WireFrameForPlayer = false, WireFrameForCapsule = false, TransparencyForPlayer = true, OpacityForPlayer = 0.5, xPos = 0, yPos = 5, zPos = 0, capsuleSettings = {}) {
    const entity = world.createEntity();

    // Match the box roughly to the capsule for clearer debugging
    var xValue = HorizontalLenght;
    var yValue = VerticalLenght;

    const radius = xValue;
    const halfHeight = yValue;
    const totalHeight = 2 * halfHeight + 2 * radius;

    const geometry = new THREE.BoxGeometry(radius * 2, totalHeight, radius * 2);
    const material = new THREE.MeshNormalMaterial({
        wireframe: WireFrameForPlayer,
        transparent: TransparencyForPlayer,
        opacity: OpacityForPlayer,
        depthWrite: !TransparencyForPlayer
    });
    const mesh = new THREE.Mesh(geometry, material);

    // Acréscimo de sombras
    mesh.castShadow = ShadowsState;

    // --- DEBUG: show capsule collider as wireframe ---
    // IMPORTANT: keep these numbers matching CapsuleCollider below
    const debugRadius = xValue;
    const debugHalfHeight = yValue;

    const capsuleGeo = new THREE.CapsuleGeometry(debugRadius, debugHalfHeight * 2, 8, 16)
    const capsuleMat = new THREE.MeshBasicMaterial({
        color: capsuleSettings.color ?? "#ffffff",
        wireframe: WireFrameForCapsule,
        transparent: capsuleSettings.transparent ?? true,
        opacity: capsuleSettings.opacity ?? 0.85,
        depthTest: WireFrameForCapsule // draw on top of everything IF wireframe activated
    });

    const capsuleDebug = new THREE.Mesh(capsuleGeo, capsuleMat);
    capsuleDebug.visible = capsuleSettings.visible ?? WireFrameForCapsule;
    scene.add(capsuleDebug);

    scene.add(mesh);

    world.addComponent(entity, new Transform(xPos, yPos, zPos));
    world.addComponent(entity, new Velocity());
    world.addComponent(entity, new Mesh(mesh));
    world.addComponent(entity, new Health(100));
    world.addComponent(entity, new PlayerControlled());
    world.addComponent(entity, new Input());
    world.addComponent(entity, new ControllerSettings());
    world.addComponent(entity, new Grounded());
    world.addComponent(entity, new DynamicBody());
    // world.addComponent(entity, new ColliderAABB(0.5, 0.5, 0.5));
    world.addComponent(entity, new CapsuleCollider(radius, yValue * 2));
    world.addComponent(entity, new ControlMode());
    world.addComponent(entity, new Aim());
    world.addComponent(entity, new CameraBasis());
    world.addComponent(entity, new CapsuleDebugMesh(capsuleDebug));

    return entity;
}