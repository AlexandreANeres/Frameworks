import { CameraFollow } from "../components/CameraFollow.js";
import { CameraRig } from "../components/CameraRig.js";

export function createFollowCamera(world, targetEntity) {
    const cameraEntity = world.createEntity();

    world.addComponent(cameraEntity, new CameraRig());

    world.addComponent(cameraEntity, new CameraFollow({
        mode: "follow",
        offsetY: 3,
        offsetZ: 6,
        smoothness: 8,
        lookAtHeight: 1
    }));

    // Store the target on the rig
    const rig = world.getComponent(cameraEntity, CameraRig);
    rig.target = targetEntity;

    return cameraEntity;
}

export function createFirstPersonCamera(world, targetEntity) {
    const cameraEntity = world.createEntity();

    world.addComponent(cameraEntity, new CameraRig());
    world.addComponent(cameraEntity, new CameraFollow({
        mode: "firstPerson",
        offsetY: 1.6,
        offsetZ: 0,
        smoothness: 20,
        lookAtHeight: 0
    }));

    const rig = world.getComponent(cameraEntity, CameraRig);
    rig.target = targetEntity;

    return cameraEntity;
}