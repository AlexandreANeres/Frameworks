import { Transform } from "../components/Transform.js";
import { AmbientLightComponent } from "../components/AmbientLightComponent.js";
import { DirectionalLightComponent } from "../components/DirectionalLightComponent.js";

export function createAmbientLight(world, { color = 0xffffff, intensity = 0.35 } = {}) {
    const e = world.createEntity();
    world.addComponent(e, new AmbientLightComponent(color, intensity));
    return e;
}

export function createDirectionalLight(world, { x = 5, y = 10, z = 5, color = 0xffffff, intensity = 0.9, resolution = 2048, area = 8, bias = -0.0001} = {}) {
    const e = world.createEntity();
    world.addComponent(e, new Transform(x, y, z));
    const light = new DirectionalLightComponent(color, intensity);
    light.Setting(resolution, area, bias);
    world.addComponent(e, light);
    return e;
}