import "./style/style.css";
import "./style/modal.css";
import { world } from "./engine/world.js";

world(({
    initializer,
    StartPlayer,
    StartWall,
    StartGround,
    StartCamera,
    StartLight,
    StartStair,
    StartBox,
    StartSphere
}) => {
    // Tudo criado aqui aparece no cenário e na lista do editor.
    StartPlayer();
    StartWall("Parede do script", 0, 1, -8);
    // StartBox("Caixa", 3, 0.5, 0);
    // StartSphere("Bola", -3, 1, 0, 1.25);
    // StartGround("Piso extra", 20, 20);
    // StartCamera("Camera estatica", 0, 5, 10);
    // StartLight("Luz extra", 10, 15, 10);
    // StartStair("Escada extra", 8, 3, 6);
    // Para recursos avancados, use initializer.PlaceWall(...).
});
