import { Component } from "../ecs/Component.js";

export class Transform extends Component {
    constructor(x = 0, y = 0, z = 0, rotX = 0, rotY = 0, rotZ = 0) {
        super();
        this.x = x;
        this.y = y;
        this.z = z;
        this.rotX = rotX;
        this.rotY = rotY;
        this.rotZ = rotZ;
        this.scaleX = 1;
        this.scaleY = 1;
        this.scaleZ = 1;
    }
}

//posição x, y, z