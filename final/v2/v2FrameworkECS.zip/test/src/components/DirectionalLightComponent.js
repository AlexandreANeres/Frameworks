import { Component } from "../ecs/Component.js";

export class DirectionalLightComponent extends Component {
    constructor(color = 0xffffff, intensity = 0.8) {
        super();
        this.color = color;
        this.intensity = intensity;

        // Shadow setting
        this.castShadow = true;
    }

    Setting(resolution, area, bias) {
        this.shadowMapSize = resolution;
        this.shadowCameraSize = area;
        this.shadowBias = bias;
    }
}