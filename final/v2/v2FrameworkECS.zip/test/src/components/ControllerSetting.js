import { Component } from "../ecs/Component.js";

export class ControllerSettings extends Component {
    constructor() {
        super();

        // Movement
        this.walkSpeed = 3;
        this.runSpeed = 6;
        this.acceleration = 25; // how fast velocity changes

        // Jump
        this.jumpSpeed = 7;
        this.jumpBufferSeconds = 0.12; // press jump slightly early
        this.coyoteSeconds = 0.10;     // jump slightly after leaving ground

        // Step / slope polish
        this.stepHeight = 0.35; //how high we can step up
        this.stepForward = 0.25; //how far forward we prope fora step
        this.slopeLimitDeg = 45; //max walkable slope
        this.groundSnapDist = 0.2; // small snap to keep grounded on gentle slopes

        // Friction / damping polish
        this.groundFriction = 18; //how fast we slow down when no input
        this.airControl = 0.35; //percent control in air
    }
}