import { Component } from "../ecs/Component.js";

export class Grounded extends Component {
    constructor() {
        super();

        // Basis rounded state
        this.isGrounded = true;
        this.coyoteTimer = 0;

        // Contact info
        this.normalX = 0;
        this.normalY = -1;
        this.normalZ = 0;

        this.slopeAngleDeg = 0;
        this.isWalkable = true;
    }

    reset() {
        this.isGrounded = false;

        // Start low so collisions can pick the best (most upward) surface
        this.normalX = 0;
        this.normalY = -1;
        this.normalZ = 0;
        this.slopeAngleDeg = 0;
        this.isWalkable = true;
    }
}