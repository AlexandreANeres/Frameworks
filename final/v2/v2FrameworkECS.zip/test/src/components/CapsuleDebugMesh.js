import { Component } from '../ecs/Component.js';

export class CapsuleDebugMesh extends Component {
    constructor(mesh) {
        super();
        this.mesh = mesh;
    }
}