import { createBaseObjects, defaultProjectSettings } from "./projectData.js";

const wall = (label, x, y, z, width, height, depth) => ({
    kind: "wall",
    label,
    permanent: false,
    values: { x, y, z, width, height, depth }
});

const shape = (label, geometryType, x, y, z, dimensions = {}) => ({
    kind: "geometry",
    label,
    permanent: false,
    values: {
        geometryType,
        x,
        y,
        z,
        rotationX: 0,
        rotationY: 0,
        rotationZ: 0,
        scaleX: 1,
        scaleY: 1,
        scaleZ: 1,
        width: 1,
        height: 1,
        depth: 1,
        radius: 0.5,
        widthSegments: 16,
        heightSegments: 12,
        radiusTop: 0.5,
        radiusBottom: 0.5,
        radialSegments: 12,
        length: 0.8,
        capSegments: 4,
        tube: 0.2,
        tubularSegments: 24,
        p: 2,
        q: 3,
        innerRadius: 0.25,
        outerRadius: 0.65,
        thetaSegments: 24,
        phiSegments: 1,
        startX: -2,
        startY: 0,
        startZ: 0,
        control1X: -1,
        control1Y: 1,
        control1Z: 0,
        control2X: 1,
        control2Y: -1,
        control2Z: 0,
        endX: 2,
        endY: 0,
        endZ: 0,
        ...dimensions
    }
});

const objects = createBaseObjects();
objects[2].values = { horizontalLength: 100, verticalLength: 100 };
objects.push(
    wall("Arena - parede norte", 0, 2, -40, 80, 4, 1),
    wall("Arena - parede sul", 0, 2, 40, 80, 4, 1),
    wall("Arena - parede leste", 40, 2, 0, 1, 4, 80),
    wall("Arena - parede oeste", -40, 2, 0, 1, 4, 80),

    wall("Casa azul - frente", -14, 1.5, -17, 9, 3, 0.5),
    wall("Casa azul - fundo", -14, 1.5, -7, 9, 3, 0.5),
    wall("Casa azul - esquerda", -18.5, 1.5, -12, 0.5, 3, 10),
    wall("Casa azul - direita", -9.5, 1.5, -12, 0.5, 3, 10),
    shape("Casa azul - telhado", "box", -14, 3.25, -12, { width: 10, height: 0.5, depth: 11 }),

    wall("Casa vermelha - frente", 14, 1.5, -17, 9, 3, 0.5),
    wall("Casa vermelha - fundo", 14, 1.5, -7, 9, 3, 0.5),
    wall("Casa vermelha - esquerda", 9.5, 1.5, -12, 0.5, 3, 10),
    wall("Casa vermelha - direita", 18.5, 1.5, -12, 0.5, 3, 10),
    shape("Casa vermelha - telhado", "box", 14, 3.25, -12, { width: 10, height: 0.5, depth: 11 }),

    wall("Torre - base", 0, 0.5, -8, 8, 1, 8),
    wall("Torre - coluna 1", -3, 3, -11, 0.7, 5, 0.7),
    wall("Torre - coluna 2", 3, 3, -11, 0.7, 5, 0.7),
    wall("Torre - coluna 3", -3, 3, -5, 0.7, 5, 0.7),
    wall("Torre - coluna 4", 3, 3, -5, 0.7, 5, 0.7),
    shape("Torre - plataforma", "box", 0, 5.7, -8, { width: 7, height: 0.7, depth: 7 }),
    shape("Torre - esfera", "sphere", 0, 7, -8, { radius: 1.2 }),

    wall("Labirinto - bloco 1", -12, 1, 8, 8, 2, 0.7),
    wall("Labirinto - bloco 2", -5, 1, 13, 0.7, 2, 10),
    wall("Labirinto - bloco 3", -1, 1, 7, 8, 2, 0.7),
    wall("Labirinto - bloco 4", 6, 1, 12, 0.7, 2, 11),
    wall("Labirinto - bloco 5", 12, 1, 6, 8, 2, 0.7),
    wall("Plataforma baixa", 20, 0.4, 5, 8, 0.8, 8),
    wall("Plataforma alta", 28, 1.5, 5, 7, 3, 7),

    {
        kind: "stair",
        label: "Escada da torre",
        permanent: false,
        values: { steps: 12, stepHeight: 0.35, stepDepth: 0.65, x: -3, width: 3 }
    },
    {
        kind: "stair",
        label: "Escada das plataformas",
        permanent: false,
        values: { steps: 8, stepHeight: 0.2, stepDepth: 0.8, x: 23, width: 3 }
    },

    shape("Esfera grande", "sphere", -24, 1.5, 12, { radius: 1.5, widthSegments: 24, heightSegments: 16 }),
    shape("Esfera pequena", "sphere", -20, 0.7, 16, { radius: 0.7 }),
    shape("Pilar cilíndrico", "cylinder", -24, 2, 20, { radiusTop: 0.8, radiusBottom: 0.8, height: 4, radialSegments: 16 }),
    shape("Cone de sinalização", "cone", -19, 1, 22, { radius: 0.8, height: 2, radialSegments: 8 }),
    shape("Cápsula", "capsule", -14, 1, 24, { radius: 0.6, length: 1.2 }),
    shape("Torus", "torus", -8, 1.5, 24, { radius: 1.2, tube: 0.25, radialSegments: 10, tubularSegments: 32 }),
    shape("Torus knot", "torusKnot", -2, 1.5, 24, { radius: 1, tube: 0.22, tubularSegments: 48, radialSegments: 8 }),
    shape("Anel plano", "ring", 4, 1, 24, { innerRadius: 0.5, outerRadius: 1.4, thetaSegments: 32 }),
    shape("Tubo curvo", "tube", 10, 1, 24, { radius: 0.2, tubularSegments: 40, radialSegments: 8 }),
    shape("Cubo girado", "box", 17, 1, 24, { width: 2, height: 2, depth: 2, rotationY: Math.PI / 5 }),
    shape("Cilindro baixo", "cylinder", 23, 0.5, 24, { radiusTop: 1.2, radiusBottom: 1.2, height: 1, radialSegments: 20 }),
    shape("Cone alto", "cone", 29, 1.5, 24, { radius: 1, height: 3, radialSegments: 12 }),

    {
        kind: "light",
        label: "Luz direcional principal",
        permanent: false,
        values: {
            x: 30,
            y: 40,
            z: 20,
            intensity: 0.55,
            resolution: 2048,
            area: 50,
            bias: -0.00001
        }
    }
);

export default {
    id: "template-test",
    version: 1,
    templateRevision: 2,
    name: "Fase de teste",
    description: "Arena com duas casas, torre, labirinto, plataformas, escadas e formas variadas.",
    template: true,
    settings: { ...defaultProjectSettings },
    skyboxSource: null,
    objects
};
