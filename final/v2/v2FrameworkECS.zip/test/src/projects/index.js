import { validateProject } from "../engine/project/projectFormat.js";

const projectModules = import.meta.glob("./*Project.js", {
    eager: true,
    import: "default"
});

export const hubProjects = Object.entries(projectModules)
    .map(([path, project]) => ({
        ...validateProject(project),
        template: true,
        hubPath: path
    }))
    .sort((first, second) => first.name.localeCompare(second.name));

if (hubProjects.length === 0) {
    throw new Error("Nenhum projeto foi encontrado em src/projects/*Project.js.");
}
