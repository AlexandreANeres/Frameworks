import { createBaseObjects, defaultProjectSettings } from "./projectData.js";

export default {
    id: "template-default",
    version: 1,
    templateRevision: 1,
    name: "Projeto padrão",
    description: "Cena inicial com jogador, câmera, chão e luz ambiente.",
    template: true,
    settings: { ...defaultProjectSettings },
    skyboxSource: null,
    objects: createBaseObjects()
};
