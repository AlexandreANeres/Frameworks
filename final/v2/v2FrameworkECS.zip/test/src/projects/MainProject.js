import { createBaseObjects, defaultProjectSettings } from "./projectData.js";

export default {
    id: "template-main",
    version: 1,
    templateRevision: 1,
    name: "Main",
    description: "Projeto inicial para construir o cenário com código no main.js ou pelo editor.",
    template: true,
    settings: { ...defaultProjectSettings },
    skyboxSource: null,
    objects: createBaseObjects()
};
