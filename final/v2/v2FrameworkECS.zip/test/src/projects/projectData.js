export const defaultProjectSettings = {
    shadowsEnabled: true,
    shadowResolution: 2048,
    renderDistance: 1000,
    cameraFov: 75
};

export function createBaseObjects() {
    return [
        {
            kind: "player",
            label: "Player",
            permanent: true,
            values: {
                shadows: true,
                horizontalLength: 0.5,
                verticalLength: 0.5,
                wireframePlayer: false,
                wireframeCapsule: false,
                transparent: true,
                opacity: 0.5,
                x: 0,
                y: 5,
                z: 0
            }
        },
        {
            kind: "camera",
            label: "Câmera",
            permanent: true,
            values: {
                type: "follow",
                x: 0,
                y: 2,
                z: 5,
                lookAtX: 0,
                lookAtY: 1,
                lookAtZ: 0
            }
        },
        {
            kind: "ground",
            label: "Chão",
            permanent: true,
            values: { horizontalLength: 50, verticalLength: 50 }
        },
        {
            kind: "ambient",
            label: "Luz ambiente",
            permanent: true,
            values: { intensity: 0.35 }
        }
    ];
}
